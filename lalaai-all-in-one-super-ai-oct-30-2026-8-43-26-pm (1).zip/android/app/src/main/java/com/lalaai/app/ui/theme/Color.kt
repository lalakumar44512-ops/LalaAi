package com.lalaai.app.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF8B5CF6)
val PurpleDark = Color(0xFF6D28D9)
val BlueAccent = Color(0xFF3B82F6)
val CyanAccent = Color(0xFF06B6D4)

// Futuristic Dark Palette
val DarkBg = Color(0xFF090D16)
val DarkSurface = Color(0xFF131B2E)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkBorder = Color(0xFF334155)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val NeonPurple = Color(0xFFA855F7)
val NeonBlue = Color(0xFF60A5FA)
