package com.lalaai.app.data

import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.lalaai.app.data.model.ActionIntent
import com.lalaai.app.data.model.AppLanguage
import com.lalaai.app.data.model.ChatMessage
import com.lalaai.app.data.model.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class GeminiApiClient(private val getApiKey: () -> String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun generateChat(
        history: List<ChatMessage>,
        userMessage: String,
        imageBase64: String? = null,
        imageMimeType: String? = null,
        model: String = "gemini-3.8-flash",
        language: AppLanguage = AppLanguage.AUTO
    ): Result<Pair<String, ActionIntent?>> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(Exception("Gemini API Key is missing. Configure it in LalaAI Settings."))
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

        val langPrompt = when (language) {
            AppLanguage.HINDI -> "Always reply in fluent, polite Hindi (Devanagari script)."
            AppLanguage.HINGLISH -> "Reply in modern, natural Hinglish (Hindi words in English alphabet)."
            AppLanguage.ENGLISH -> "Reply in crisp, professional English."
            AppLanguage.AUTO -> "Detect whether the user speaks English, Hindi or Hinglish, and reply accordingly."
        }

        val systemInstructionText = """
            You are LalaAI – All-in-One Super AI, an ultra-smart Android companion.
            $langPrompt
            When the user requests an Android phone action (e.g. open YouTube, call, launch camera, open WhatsApp, open settings, navigate, search web), append an action tag at the end:
            [ACTION:{"type":"OPEN_APP"|"SEARCH_YOUTUBE"|"DIAL_PHONE"|"SEND_WHATSAPP"|"OPEN_CAMERA"|"OPEN_SETTINGS"|"NAVIGATE"|"WEB_SEARCH","params":{"query":"...","target":"..."},"title":"Action Title"}]
            Provide rich, structured, friendly answers.
        """.trimIndent()

        // Build request JSON
        val requestJson = JsonObject().apply {
            // System instruction
            val sysInstructionObj = JsonObject().apply {
                val partsArray = JsonArray().apply {
                    add(JsonObject().apply { addProperty("text", systemInstructionText) })
                }
                add("parts", partsArray)
            }
            add("systemInstruction", sysInstructionObj)

            // Contents array
            val contentsArray = JsonArray()

            // Add previous history
            for (msg in history.takeLast(6)) {
                val turnObj = JsonObject().apply {
                    addProperty("role", if (msg.role == MessageRole.USER) "user" else "model")
                    val parts = JsonArray().apply {
                        add(JsonObject().apply { addProperty("text", msg.content) })
                    }
                    add("parts", parts)
                }
                contentsArray.add(turnObj)
            }

            // Current user message
            val currentTurn = JsonObject().apply {
                addProperty("role", "user")
                val parts = JsonArray()

                if (!imageBase64.isNullOrBlank()) {
                    val inlineData = JsonObject().apply {
                        addProperty("mimeType", imageMimeType ?: "image/jpeg")
                        addProperty("data", imageBase64)
                    }
                    parts.add(JsonObject().apply { add("inlineData", inlineData) })
                }

                parts.add(JsonObject().apply { addProperty("text", userMessage) })
                add("parts", parts)
            }
            contentsArray.add(currentTurn)

            add("contents", contentsArray)
        }

        val body = requestJson.toString().toRequestBody(jsonMediaType)
        val request = Request.Builder()
            .url(url)
            .post(body)
            .addHeader("User-Agent", "aistudio-build")
            .build()

        try {
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Gemini API HTTP ${response.code}: $responseBody"))
            }

            val rootJson = gson.fromJson(responseBody, JsonObject::class.java)
            val candidates = rootJson.getAsJsonArray("candidates")
            if (candidates == null || candidates.size() == 0) {
                return@withContext Result.failure(Exception("No candidate returned by Gemini model"))
            }

            val parts = candidates[0].asJsonObject
                .getAsJsonObject("content")
                ?.getAsJsonArray("parts")

            val rawText = parts?.get(0)?.asJsonObject?.get("text")?.asString ?: "No response generated"

            // Extract Action Intent if present
            val (cleanText, intent) = parseActionIntent(rawText)

            return@withContext Result.success(Pair(cleanText, intent))
        } catch (e: Exception) {
            return@withContext Result.failure(e)
        }
    }

    private fun parseActionIntent(text: String): Pair<String, ActionIntent?> {
        val regex = Regex("\\[ACTION:(.*?)\\]")
        val match = regex.find(text) ?: return Pair(text, null)

        val jsonStr = match.groupValues[1]
        val cleanText = text.replace(match.value, "").trim()

        return try {
            val obj = gson.fromJson(jsonStr, JsonObject::class.java)
            val type = obj.get("type")?.asString ?: "OPEN_APP"
            val title = obj.get("title")?.asString ?: "Execute Phone Action"
            val paramsObj = obj.getAsJsonObject("params")
            val paramsMap = mutableMapOf<String, String>()
            paramsObj?.keySet()?.forEach { k ->
                paramsMap[k] = paramsObj.get(k).asString
            }

            val action = ActionIntent(
                type = type,
                params = paramsMap,
                title = title,
                description = "LalaAI requested permission to execute $type",
                requiresConfirmation = true
            )
            Pair(cleanText, action)
        } catch (e: Exception) {
            Pair(cleanText, null)
        }
    }
}
