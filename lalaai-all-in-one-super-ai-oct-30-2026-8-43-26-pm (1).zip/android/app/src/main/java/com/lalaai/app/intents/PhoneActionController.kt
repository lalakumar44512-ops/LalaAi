package com.lalaai.app.intents

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import com.lalaai.app.data.model.ActionIntent

class PhoneActionController(private val context: Context) {

    /**
     * Executes an Android ActionIntent with explicit security verification.
     * Never performs silent execution.
     */
    fun executeIntent(action: ActionIntent): Result<String> {
        return try {
            when (action.type) {
                "OPEN_APP" -> {
                    val packageName = action.params["target"] ?: action.params["package"]
                    if (packageName.isNullOrBlank()) {
                        return Result.failure(Exception("Package name missing"))
                    }
                    val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(launchIntent)
                        Result.success("Launched app: $packageName")
                    } else {
                        // Open Play Store if not installed
                        val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(marketIntent)
                        Result.success("Opened Play Store for $packageName")
                    }
                }

                "SEARCH_YOUTUBE" -> {
                    val query = action.params["query"] ?: ""
                    val ytIntent = Intent(Intent.ACTION_SEARCH).apply {
                        setPackage("com.google.android.youtube")
                        putExtra("query", query)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    if (ytIntent.resolveActivity(context.packageManager) != null) {
                        context.startActivity(ytIntent)
                        Result.success("Opened YouTube Search for '$query'")
                    } else {
                        // Fallback browser search
                        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(webIntent)
                        Result.success("Opened Web YouTube for '$query'")
                    }
                }

                "DIAL_PHONE" -> {
                    val number = action.params["number"] ?: action.params["target"] ?: ""
                    // Use ACTION_DIAL (never ACTION_CALL) to always require user to press call button
                    val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(dialIntent)
                    Result.success("Opened Phone Dialer for $number")
                }

                "SEND_WHATSAPP" -> {
                    val text = action.params["text"] ?: action.params["query"] ?: ""
                    val waIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?text=" + Uri.encode(text))).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(waIntent)
                    Result.success("Opened WhatsApp with message")
                }

                "OPEN_CAMERA" -> {
                    val cameraIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(cameraIntent)
                    Result.success("Opened Camera")
                }

                "SET_ALARM" -> {
                    val message = action.params["label"] ?: "LalaAI Reminder"
                    val hour = action.params["hour"]?.toIntOrNull() ?: 8
                    val minutes = action.params["minutes"]?.toIntOrNull() ?: 0

                    val alarmIntent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                        putExtra(AlarmClock.EXTRA_MESSAGE, message)
                        putExtra(AlarmClock.EXTRA_HOUR, hour)
                        putExtra(AlarmClock.EXTRA_MINUTES, minutes)
                        putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(alarmIntent)
                    Result.success("Set Alarm for %02d:%02d".format(hour, minutes))
                }

                "OPEN_SETTINGS" -> {
                    val settingsIntent = Intent(Settings.ACTION_SETTINGS).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(settingsIntent)
                    Result.success("Opened Device Settings")
                }

                "NAVIGATE" -> {
                    val location = action.params["location"] ?: action.params["query"] ?: ""
                    val mapIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(location))).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(mapIntent)
                    Result.success("Opened Navigation for '$location'")
                }

                "WEB_SEARCH" -> {
                    val query = action.params["query"] ?: ""
                    val searchIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(searchIntent)
                    Result.success("Searched Google for '$query'")
                }

                else -> {
                    Result.failure(Exception("Unsupported action type: ${action.type}"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
