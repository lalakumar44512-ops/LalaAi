package com.lalaai.app.data.model

import java.util.UUID

enum class MessageRole {
    USER, MODEL, SYSTEM
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val imageBase64: String? = null,
    val imageMimeType: String? = null,
    val actionIntent: ActionIntent? = null,
    val groundingSources: List<String> = emptyList(),
    val isStreaming: Boolean = false
)

data class ActionIntent(
    val id: String = UUID.randomUUID().toString(),
    val type: String, // OPEN_APP, SEARCH_YOUTUBE, DIAL_PHONE, SEND_WHATSAPP, OPEN_CAMERA, OPEN_SETTINGS, NAVIGATE, WEB_SEARCH
    val params: Map<String, String> = emptyMap(),
    val title: String,
    val description: String,
    val requiresConfirmation: Boolean = true,
    var isExecuted: Boolean = false
)

data class AIFeature(
    val id: String,
    val number: Int,
    val title: String,
    val subtitle: String,
    val category: String, // "Brain & Core", "Creative & Media", "Productivity", "Education & STEM"
    val icon: String,
    val promptTemplate: String
)

data class AIModelOption(
    val id: String,
    val name: String,
    val badge: String,
    val description: String
)

enum class AppLanguage(val code: String, val displayName: String) {
    AUTO("auto", "Auto Detect (Hindi / English)"),
    HINDI("hi", "हिन्दी (Hindi)"),
    ENGLISH("en", "English"),
    HINGLISH("hinglish", "Hinglish (Hybrid)")
}

data class AppSettings(
    val apiKey: String = "",
    val selectedModel: String = "gemini-3.8-flash",
    val language: AppLanguage = AppLanguage.AUTO,
    val darkTheme: Boolean = true,
    val voiceSpeed: Float = 1.0f,
    val voicePitch: Float = 1.0f,
    val accessibilityEnabled: Boolean = false,
    val confirmSensitiveActions: Boolean = true
)
