package com.lalaai.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.content.ContextCompat
import com.lalaai.app.ui.screens.*
import com.lalaai.app.ui.theme.DarkBg
import com.lalaai.app.ui.theme.DarkSurface
import com.lalaai.app.ui.theme.LalaAITheme
import com.lalaai.app.ui.theme.Purple40
import com.lalaai.app.viewmodel.MainViewModel

data class NavItem(val route: String, val title: String, val icon: ImageVector)

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Request runtime permissions if not granted
        checkAndRequestPermissions()

        setContent {
            val uiState by viewModel.uiState.collectAsState()

            LalaAITheme(darkTheme = uiState.settings.darkTheme) {
                val navItems = listOf(
                    NavItem("home", "Home", Icons.Default.Home),
                    NavItem("chat", "AI Chat", Icons.Default.ChatBubble),
                    NavItem("explore", "Explore", Icons.Default.GridView),
                    NavItem("settings", "Settings", Icons.Default.Settings)
                )

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = DarkBg,
                    bottomBar = {
                        NavigationBar(containerColor = DarkSurface) {
                            navItems.forEach { item ->
                                NavigationBarItem(
                                    selected = uiState.currentRoute == item.route,
                                    onClick = { viewModel.setRoute(item.route) },
                                    icon = { Icon(item.icon, contentDescription = item.title) },
                                    label = { Text(item.title) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Purple40,
                                        indicatorColor = Purple40.copy(alpha = 0.2f)
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Surface(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                        color = DarkBg
                    ) {
                        when (uiState.currentRoute) {
                            "home" -> HomeScreen(
                                onNavigate = { viewModel.setRoute(it) },
                                onFeatureSelected = { feat ->
                                    viewModel.selectFeature(feat)
                                    viewModel.sendMessage(feat.promptTemplate)
                                    viewModel.setRoute("chat")
                                },
                                onQuickPrompt = { prompt ->
                                    viewModel.sendMessage(prompt)
                                }
                            )
                            "chat" -> ChatScreen(
                                messages = uiState.messages,
                                isLoading = uiState.isLoading,
                                isListening = uiState.isListening,
                                onSendMessage = { viewModel.sendMessage(it) },
                                onStartVoice = { viewModel.startVoiceInput() },
                                onStopVoice = { viewModel.stopVoiceInput() },
                                onSpeak = { viewModel.speakText(it) },
                                onExecuteAction = { viewModel.confirmAndExecuteAction(it) },
                                onClearChat = { viewModel.clearChat() }
                            )
                            "explore" -> ExploreScreen(
                                onFeatureSelected = { feat ->
                                    viewModel.selectFeature(feat)
                                    viewModel.sendMessage(feat.promptTemplate)
                                    viewModel.setRoute("chat")
                                }
                            )
                            "settings" -> SettingsScreen(
                                settings = uiState.settings,
                                onSaveSettings = { viewModel.updateSettings(it) },
                                onClearChat = { viewModel.clearChat() }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun checkAndRequestPermissions() {
        val permissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA
        )
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }
}
