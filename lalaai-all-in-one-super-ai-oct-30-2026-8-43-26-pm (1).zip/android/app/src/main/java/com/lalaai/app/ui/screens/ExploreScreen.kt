package com.lalaai.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lalaai.app.data.model.AIFeature
import com.lalaai.app.ui.theme.*

@Composable
fun ExploreScreen(
    onFeatureSelected: (AIFeature) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    val allFeatures = remember {
        listOf(
            AIFeature("chat", 1, "AI Chat Assistant", "Universal multi-turn conversational AI in Hindi & English", "Core Brain", "chat", "Hello LalaAI! Let's explore."),
            AIFeature("voice", 2, "Voice Assistant", "Hands-free speech-to-text & instant spoken responses", "Core Brain", "mic", "Start voice listening."),
            AIFeature("image", 3, "AI Image Generation", "Prompt crafting, style engineering & image visualization", "Creative", "image", "Create an ultra-detailed futuristic cyber city in neon purple and gold."),
            AIFeature("video", 4, "AI Video Generation", "Google Veo prompt builder, camera directions & storyboards", "Creative", "videocam", "Generate a cinematic 4K video prompt with dramatic lighting."),
            AIFeature("code", 5, "AI Coding Assistant", "Full-stack code generator, bug fixer & architecture optimizer", "STEM", "code", "Write a clean Kotlin Jetpack Compose composable with state hoisting."),
            AIFeature("search", 6, "AI Web Search Grounding", "Live search grounding with cited sources & real-time info", "Core Brain", "search", "Search latest news on space exploration and summarize key breakthroughs."),
            AIFeature("translate", 7, "AI Translator", "Natural translation between Hindi, English, and 50+ languages", "Productivity", "translate", "Translate: 'Innovation distinguishes between a leader and a follower' into pure Hindi."),
            AIFeature("writing", 8, "AI Writing Assistant", "Essays, articles, formal letters & executive proposals", "Productivity", "edit", "Write a compelling proposal on adopting AI in sustainable agriculture."),
            AIFeature("homework", 9, "AI Homework Helper", "Step-by-step tutoring without giving away dry answers", "Education", "school", "Explain the photoelectric effect with real-world intuition."),
            AIFeature("pdf", 10, "AI PDF Reader", "Extract takeaways, ask questions & summarize uploaded PDFs", "Productivity", "picture_as_pdf", "Analyze the uploaded document and list core obligations."),
            AIFeature("document", 11, "AI Document Analyzer", "Resume review, contract audit & technical brief parser", "Productivity", "description", "Analyze this software engineer resume and highlight areas for improvement."),
            AIFeature("math", 12, "AI Math Solver", "Calculus, linear algebra & step-by-step arithmetic", "STEM", "calculate", "Solve step-by-step: Integrate 2x * e^(x^2) dx from 0 to 1."),
            AIFeature("study", 13, "AI Study Assistant", "Interactive revision flashcards and quiz generator", "Education", "menu_book", "Create 5 high-yield revision flashcards on Operating System scheduling algorithms."),
            AIFeature("music", 14, "AI Music Generation", "Lyrics writer, chord progression & BPM synthesizer guide", "Creative", "music_note", "Write a synthwave cyberpunk song about AI consciousness with chords."),
            AIFeature("summarize", 15, "AI Summarizer", "TL;DR, executive briefs & bullet point breakdowns", "Productivity", "compress", "Summarize this long article into 3 critical takeaways."),
            AIFeature("email", 16, "AI Email Writer", "Professional, sales pitch & follow-up email drafts", "Productivity", "email", "Draft a respectful follow-up email after a job interview."),
            AIFeature("story", 17, "AI Story Generator", "Interactive choose-your-own-path fictional narratives", "Creative", "auto_stories", "Write an atmospheric mystery story set in Varanasi in 2050."),
            AIFeature("content", 18, "AI Content Creator", "Viral YouTube scripts, Instagram reels & LinkedIn hooks", "Creative", "movie", "Write 3 viral opening hooks for a YouTube video about future tech."),
            AIFeature("grammar", 19, "AI Grammar Checker", "Proofreading, tone refinement & diff highlight tracker", "Productivity", "spellcheck", "Fix grammar and enhance clarity in this paragraph."),
            AIFeature("knowledge", 20, "AI Knowledge Assistant", "Deep encyclopedia, historical timelines & conceptual maps", "Education", "psychology", "Provide a comprehensive timeline of the Industrial Revolution to AI era.")
        )
    }

    val categories = listOf("All", "Core Brain", "Creative", "STEM", "Education", "Productivity")

    val filteredFeatures = allFeatures.filter { feat ->
        (selectedCategory == "All" || feat.category == selectedCategory) &&
        (feat.title.contains(searchQuery, ignoreCase = true) || feat.subtitle.contains(searchQuery, ignoreCase = true))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(16.dp)
    ) {
        Text(
            text = "Explore 20 AI Features",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        Text(
            text = "Every superpower built-in, production ready.",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Search Box
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search tools (e.g. math, code, translate)...", color = TextSecondary) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = TextSecondary) },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = DarkSurface,
                unfocusedContainerColor = DarkSurface,
                focusedBorderColor = Purple40,
                unfocusedBorderColor = DarkBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Categories Scroll
        ScrollableTabRow(
            selectedTabIndex = categories.indexOf(selectedCategory).coerceAtLeast(0),
            containerColor = Color.Transparent,
            edgePadding = 0.dp,
            divider = {}
        ) {
            categories.forEach { cat ->
                Tab(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    text = {
                        Text(
                            cat,
                            color = if (selectedCategory == cat) Purple80 else TextSecondary,
                            fontWeight = if (selectedCategory == cat) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Feature List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(filteredFeatures) { feat ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onFeatureSelected(feat) },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Purple40.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "#${feat.number}",
                                color = NeonPurple,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    feat.title,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Badge(
                                    containerColor = DarkSurfaceVariant,
                                    contentColor = TextSecondary
                                ) {
                                    Text(feat.category, fontSize = 10.sp)
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                feat.subtitle,
                                color = TextSecondary,
                                fontSize = 12.sp,
                                maxLines = 2
                            )
                        }

                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = "Open",
                            tint = TextSecondary
                        )
                    }
                }
            }
        }
    }
}
