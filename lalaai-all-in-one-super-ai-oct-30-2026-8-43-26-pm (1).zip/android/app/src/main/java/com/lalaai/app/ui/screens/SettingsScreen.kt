package com.lalaai.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lalaai.app.data.model.AppLanguage
import com.lalaai.app.data.model.AppSettings
import com.lalaai.app.ui.theme.*

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onSaveSettings: (AppSettings) -> Unit,
    onClearChat: () -> Unit
) {
    var apiKey by remember { mutableStateOf(settings.apiKey) }
    var showApiKey by remember { mutableStateOf(false) }
    var selectedModel by remember { mutableStateOf(settings.selectedModel) }
    var selectedLang by remember { mutableStateOf(settings.language) }
    var darkTheme by remember { mutableStateOf(settings.darkTheme) }
    var confirmActions by remember { mutableStateOf(settings.confirmSensitiveActions) }
    var voiceSpeed by remember { mutableFloatStateOf(settings.voiceSpeed) }
    var showClearDialog by remember { mutableStateOf(false) }

    val models = listOf(
        Pair("gemini-3.8-flash", "Gemini 3.8 Flash (Recommended - Fast & Multimodal)"),
        Pair("gemini-3.1-flash-lite", "Gemini 3.1 Flash Lite (Ultra Low Latency)"),
        Pair("gemini-4-argon", "Gemini 4 Argon (Deep Complex Reasoning)")
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "LalaAI Settings",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                "Configure AI models, API keys, languages & privacy",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }

        // Section: Gemini AI Engine
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VpnKey, contentDescription = "API Key", tint = Purple40)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Google Gemini API Key", fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Stored securely in private application storage. Kept local on your device.",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = {
                            apiKey = it
                            onSaveSettings(settings.copy(apiKey = it))
                        },
                        placeholder = { Text("Enter Gemini API key (AIzaSy...)", color = TextSecondary) },
                        visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showApiKey = !showApiKey }) {
                                Icon(
                                    if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle Visibility",
                                    tint = TextSecondary
                                )
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = DarkSurfaceVariant,
                            unfocusedContainerColor = DarkSurfaceVariant,
                            focusedBorderColor = Purple40,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Section: Model Selection
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Memory, contentDescription = "Model", tint = BlueAccent)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("AI Model Selection", fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    models.forEach { (id, label) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = selectedModel == id,
                                onClick = {
                                    selectedModel = id
                                    onSaveSettings(settings.copy(selectedModel = id))
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = Purple40)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(label, fontSize = 13.sp, color = TextPrimary)
                        }
                    }
                }
            }
        }

        // Section: Language Preference
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Translate, contentDescription = "Language", tint = CyanAccent)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Default Language Response", fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    AppLanguage.values().forEach { lang ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = selectedLang == lang,
                                onClick = {
                                    selectedLang = lang
                                    onSaveSettings(settings.copy(language = lang))
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = CyanAccent)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(lang.displayName, fontSize = 13.sp, color = TextPrimary)
                        }
                    }
                }
            }
        }

        // Section: Security & Android Phone Control
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = "Security", tint = NeonPurple)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Android Phone Control & Safety", fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Confirm Sensitive Actions", fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 14.sp)
                            Text("Always require explicit confirmation before launching intents or dialing", fontSize = 12.sp, color = TextSecondary)
                        }
                        Switch(
                            checked = confirmActions,
                            onCheckedChange = {
                                confirmActions = it
                                onSaveSettings(settings.copy(confirmSensitiveActions = it))
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Purple40)
                        )
                    }
                }
            }
        }

        // Section: Voice Speed
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = "Voice", tint = BlueAccent)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Voice Speed: ${"%.1f".format(voiceSpeed)}x", fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Slider(
                        value = voiceSpeed,
                        onValueChange = {
                            voiceSpeed = it
                            onSaveSettings(settings.copy(voiceSpeed = it))
                        },
                        valueRange = 0.5f..2.0f,
                        steps = 5,
                        colors = SliderDefaults.colors(thumbColor = Purple40, activeTrackColor = Purple40)
                    )
                }
            }
        }

        // Clear Chat & App Info
        item {
            Button(
                onClick = { showClearDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.8f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.DeleteForever, contentDescription = "Clear")
                Spacer(modifier = Modifier.width(8.dp))
                Text("Clear All Chat History")
            }

            Spacer(modifier = Modifier.height(12.dp))

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("LalaAI – All-in-One Super AI", fontWeight = FontWeight.Bold, color = TextSecondary, fontSize = 12.sp)
                Text("Version 2.5.0 • Jetpack Compose MVVM • Android 12+", color = DarkBorder, fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Clear Chat History?") },
            text = { Text("Are you sure you want to delete all saved conversations? This action cannot be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onClearChat()
                        showClearDialog = false
                    }
                ) {
                    Text("Clear", color = Color.Red)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
