package com.lalaai.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lalaai.app.data.GeminiApiClient
import com.lalaai.app.data.model.AIFeature
import com.lalaai.app.data.model.ActionIntent
import com.lalaai.app.data.model.AppLanguage
import com.lalaai.app.data.model.AppSettings
import com.lalaai.app.data.model.ChatMessage
import com.lalaai.app.data.model.MessageRole
import com.lalaai.app.intents.PhoneActionController
import com.lalaai.app.voice.VoiceManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val messages: List<ChatMessage> = emptyList(),
    val isLoading: Boolean = false,
    val isListening: Boolean = false,
    val pendingAction: ActionIntent? = null,
    val currentRoute: String = "home",
    val errorMessage: String? = null,
    val selectedFeature: AIFeature? = null,
    val settings: AppSettings = AppSettings()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val actionController = PhoneActionController(application)
    private val geminiClient = GeminiApiClient { _uiState.value.settings.apiKey }

    private var voiceManager: VoiceManager? = null

    init {
        // Initialize sample welcome message
        val welcomeMsg = ChatMessage(
            role = MessageRole.MODEL,
            content = "Namaste! I am LalaAI – All-in-One Super AI Android Assistant. I can chat in Hindi & English, write code, generate ideas, solve math, and assist with your Android device. How can I help you today?"
        )
        _uiState.update { it.copy(messages = listOf(welcomeMsg)) }

        // Setup voice manager
        voiceManager = VoiceManager(
            context = application,
            onSpeechResult = { text ->
                _uiState.update { it.copy(isListening = false) }
                sendMessage(text)
            },
            onError = { err ->
                _uiState.update { it.copy(isListening = false, errorMessage = err) }
            }
        )
    }

    fun setRoute(route: String) {
        _uiState.update { it.copy(currentRoute = route) }
    }

    fun selectFeature(feature: AIFeature?) {
        _uiState.update { it.copy(selectedFeature = feature, currentRoute = if (feature != null) "explore" else "home") }
    }

    fun updateSettings(newSettings: AppSettings) {
        _uiState.update { it.copy(settings = newSettings) }
    }

    fun startVoiceInput() {
        _uiState.update { it.copy(isListening = true) }
        voiceManager?.startListening()
    }

    fun stopVoiceInput() {
        _uiState.update { it.copy(isListening = false) }
        voiceManager?.stopListening()
    }

    fun speakText(text: String) {
        val s = _uiState.value.settings
        voiceManager?.speak(text, s.voiceSpeed, s.voicePitch)
    }

    fun stopSpeaking() {
        voiceManager?.stopSpeaking()
    }

    fun sendMessage(text: String, imageBase64: String? = null, imageMimeType: String? = null) {
        if (text.isBlank() && imageBase64 == null) return

        val userMsg = ChatMessage(
            role = MessageRole.USER,
            content = text,
            imageBase64 = imageBase64,
            imageMimeType = imageMimeType
        )

        _uiState.update {
            it.copy(
                messages = it.messages + userMsg,
                isLoading = true,
                errorMessage = null
            )
        }

        viewModelScope.launch {
            val result = geminiClient.generateChat(
                history = _uiState.value.messages,
                userMessage = text,
                imageBase64 = imageBase64,
                imageMimeType = imageMimeType,
                model = _uiState.value.settings.selectedModel,
                language = _uiState.value.settings.language
            )

            result.onSuccess { (reply, actionIntent) ->
                val modelMsg = ChatMessage(
                    role = MessageRole.MODEL,
                    content = reply,
                    actionIntent = actionIntent
                )
                _uiState.update {
                    it.copy(
                        messages = it.messages + modelMsg,
                        isLoading = false,
                        pendingAction = if (it.settings.confirmSensitiveActions) actionIntent else null
                    )
                }

                // If user opted to auto-execute without confirmation:
                if (!_uiState.value.settings.confirmSensitiveActions && actionIntent != null) {
                    confirmAndExecuteAction(actionIntent)
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = err.message ?: "Failed to generate AI response"
                    )
                }
            }
        }
    }

    fun confirmAndExecuteAction(action: ActionIntent) {
        val result = actionController.executeIntent(action)
        result.onSuccess {
            action.isExecuted = true
            _uiState.update { it.copy(pendingAction = null) }
        }.onFailure { err ->
            _uiState.update { it.copy(errorMessage = "Intent execution failed: ${err.message}") }
        }
    }

    fun cancelPendingAction() {
        _uiState.update { it.copy(pendingAction = null) }
    }

    fun clearChat() {
        val welcomeMsg = ChatMessage(
            role = MessageRole.MODEL,
            content = "Chat cleared. What would you like to explore next?"
        )
        _uiState.update { it.copy(messages = listOf(welcomeMsg), pendingAction = null) }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager?.destroy()
    }
}
