package com.lalaai.app.service

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * LalaAI Screen Assistant Accessibility Service.
 * Only activated when user explicitly enables it in Android Accessibility Settings.
 * Used exclusively for on-demand screen reading/assistance upon user trigger.
 * Strictly honors user privacy and never sends screen logs in the background.
 */
class LalaAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "LalaAccessibility"
        var isServiceRunning = false
            private set
        var lastVisibleText: String = ""
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceRunning = true
        Log.i(TAG, "LalaAI Accessibility Service connected with explicit user permission.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // Capture window text for contextual AI assistance only when user requested
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            val root = rootInActiveWindow ?: return
            val textBuilder = StringBuilder()
            extractNodeText(root, textBuilder, depth = 0)
            lastVisibleText = textBuilder.toString().take(1500)
        }
    }

    private fun extractNodeText(node: AccessibilityNodeInfo?, out: StringBuilder, depth: Int) {
        if (node == null || depth > 8) return
        val text = node.text
        if (!text.isNullOrBlank()) {
            out.append(text).append("\n")
        }
        for (i in 0 until node.childCount) {
            extractNodeText(node.getChild(i), out, depth + 1)
        }
    }

    override fun onInterrupt() {
        Log.i(TAG, "LalaAI Accessibility Service interrupted.")
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
        Log.i(TAG, "LalaAI Accessibility Service destroyed.")
    }
}
