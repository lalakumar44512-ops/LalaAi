package com.lalaai.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lalaai.app.data.model.AIFeature
import com.lalaai.app.ui.theme.*

@Composable
fun HomeScreen(
    onNavigate: (String) -> Unit,
    onFeatureSelected: (AIFeature) -> Unit,
    onQuickPrompt: (String) -> Unit
) {
    var quickInputText by remember { mutableStateOf("") }

    val quickChips = listOf(
        "⚡ Fix Python Code",
        "🇮🇳 Explain in Hindi",
        "📺 Open YouTube",
        "📐 Solve Calculus Math",
        "✉️ Write Formal Email",
        "💡 Create Viral Video Idea"
    )

    val popularFeatures = listOf(
        AIFeature("chat", 1, "AI Chat", "Bilingual Gemini Assistant", "Core", "chat", "Hello LalaAI!"),
        AIFeature("voice", 2, "Voice Assistant", "Hands-free Speech AI", "Core", "mic", "Listening for your voice command..."),
        AIFeature("code", 5, "Coding Assistant", "Full-stack Android & Web", "STEM", "code", "Write a clean Kotlin Jetpack Compose function..."),
        AIFeature("search", 6, "Web Search Grounding", "Live Google Search", "Core", "search", "What are the latest updates on space technology?"),
        AIFeature("translate", 7, "AI Translator", "Hindi <-> English & Global", "Productivity", "translate", "Translate this sentence to Hindi..."),
        AIFeature("math", 12, "Math Solver", "Step-by-step with formulas", "STEM", "calculate", "Solve this quadratic equation...")
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Header: Logo & Branding
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Purple40, BlueAccent))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "L",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "LalaAI",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )
                        Text(
                            text = "All-in-One Super AI",
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonPurple
                        )
                    }
                }

                IconButton(
                    onClick = { onNavigate("settings") },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = TextSecondary
                    )
                }
            }
        }

        // Hero Greeting Card
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    PurpleDark.copy(alpha = 0.35f),
                                    DarkSurface
                                )
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Badge(
                            containerColor = Purple40.copy(alpha = 0.2f),
                            contentColor = Purple80
                        ) {
                            Text(
                                "⚡ Powered by Google Gemini 3.8",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Namaste! What can I build or solve for you?",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Smart responses in Hindi & English, phone control, coding, math & 20 AI superpowers.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Quick Input Box
        item {
            OutlinedTextField(
                value = quickInputText,
                onValueChange = { quickInputText = it },
                placeholder = { Text("Ask anything or type a command...", color = TextSecondary) },
                shape = RoundedCornerShape(20.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurfaceVariant,
                    unfocusedContainerColor = DarkSurface,
                    focusedBorderColor = Purple40,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                trailingIcon = {
                    Row(modifier = Modifier.padding(end = 4.dp)) {
                        IconButton(onClick = { onNavigate("chat") }) {
                            Icon(Icons.Default.Mic, contentDescription = "Voice", tint = CyanAccent)
                        }
                        IconButton(
                            onClick = {
                                if (quickInputText.isNotBlank()) {
                                    onQuickPrompt(quickInputText)
                                    quickInputText = ""
                                    onNavigate("chat")
                                }
                            }
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = Purple40)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Quick Prompt Chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(quickChips) { chip ->
                    SuggestionChip(
                        onClick = {
                            onQuickPrompt(chip)
                            onNavigate("chat")
                        },
                        label = { Text(chip, fontSize = 12.sp, color = TextPrimary) },
                        shape = RoundedCornerShape(14.dp),
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = DarkSurfaceVariant
                        ),
                        border = SuggestionChipDefaults.suggestionChipBorder(
                            enabled = true,
                            borderColor = DarkBorder
                        )
                    )
                }
            }
        }

        // 20 Super AI Tools Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AI Superpowers (20 Tools)",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                TextButton(onClick = { onNavigate("explore") }) {
                    Text("View All", color = Purple40)
                }
            }
        }

        // Popular Tools Grid
        items(popularFeatures.chunked(2)) { pair ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                for (feat in pair) {
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onFeatureSelected(feat) },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Purple40.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "#${feat.number}",
                                    color = Purple80,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                feat.title,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontSize = 14.sp
                            )
                            Text(
                                feat.subtitle,
                                color = TextSecondary,
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // Android Phone Control Quick Actions
        item {
            Text(
                text = "Android Phone Control",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Supported Device Intents with User Confirmation",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        QuickActionItem("YouTube", Icons.Default.PlayArrow, NeonPurple) {
                            onQuickPrompt("Open YouTube and search latest science documentaries")
                            onNavigate("chat")
                        }
                        QuickActionItem("WhatsApp", Icons.Default.Chat, CyanAccent) {
                            onQuickPrompt("Send WhatsApp message to team")
                            onNavigate("chat")
                        }
                        QuickActionItem("Camera", Icons.Default.CameraAlt, BlueAccent) {
                            onQuickPrompt("Open camera to scan document")
                            onNavigate("chat")
                        }
                        QuickActionItem("Settings", Icons.Default.Settings, TextSecondary) {
                            onNavigate("settings")
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun QuickActionItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterAlignment,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(tint.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = title, tint = tint)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(title, fontSize = 11.sp, color = TextSecondary)
    }
}
