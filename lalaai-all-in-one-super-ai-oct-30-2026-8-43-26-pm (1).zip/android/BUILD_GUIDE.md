# LalaAI – All-in-One Super AI: Android Build & APK Guide

## 1. Project Overview
- **Application Name**: LalaAI – All-in-One Super AI
- **Package ID**: `com.lalaai.app`
- **Target Android Version**: Android 12+ (API 31 - 35)
- **Minimum SDK**: Android 8.0 (API 26)
- **UI Framework**: Jetpack Compose Material 3
- **Architecture**: MVVM + Coroutines + Flow + OkHttp

---

## 2. Building Debug APK (Android Studio / PC / Linux / Mac)

### Prerequisites:
1. JDK 17 installed (`openjdk-17-jdk`)
2. Android SDK Command-line Tools / Android Studio Iguana+

### Step 1: Open project in Android Studio
1. Open Android Studio -> **File > Open...** -> select the project root folder.
2. Allow Gradle sync to complete automatically.

### Step 2: Build Debug APK via CLI
```bash
# Make gradlew executable
chmod +x gradlew

# Run debug build
./gradlew assembleDebug
```
The compiled debug APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

---

## 3. Building Release APK (Signed for Play Store or Sideloading)

### Step 1: Generate a Keystore (if you don't already have one)
```bash
keytool -genkeypair -v -keystore lalaai-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias lalaai
```

### Step 2: Build Release APK
```bash
./gradlew assembleRelease
```
The unsigned release APK will be located at:
`app/build/outputs/apk/release/app-release-unsigned.apk`

### Step 3: Sign the APK using apksigner
```bash
$ANDROID_HOME/build-tools/35.0.0/apksigner sign \
    --ks lalaai-release-key.jks \
    --out app-release-signed.apk \
    app/build/outputs/apk/release/app-release-unsigned.apk
```

---

## 4. Building Directly on Android via Termux

You can build the APK directly on your Android phone without a computer using Termux!

### Step 1: Install Termux & Base Packages
Open Termux and run:
```bash
pkg update -y && pkg upgrade -y
pkg install -y git openjdk-17 gradle aapt zipalign
```

### Step 2: Clone / Copy LalaAI Project
```bash
# Verify Java version is 17
java -version
javac -version
```

### Step 3: Build using Gradle inside Termux
```bash
chmod +x gradlew
./gradlew assembleDebug
```
Once done, copy the APK to your Downloads folder:
```bash
cp app/build/outputs/apk/debug/app-debug.apk /sdcard/Download/LalaAI-v2.5.0-debug.apk
```
Open your file manager in Android and tap `LalaAI-v2.5.0-debug.apk` to install!

---

## 5. Security & Privacy Rules
- LalaAI **never secretly controls the device**.
- All Android phone intents (YouTube search, Phone dialer, WhatsApp message, Camera) prompt with an explicit security confirmation card before dispatching.
- Accessibility service is purely optional for on-demand screen assistance and disabled by default.
