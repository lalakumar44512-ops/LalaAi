export type Role = 'user' | 'model' | 'system';

export interface ActionIntent {
  id: string;
  type:
    | 'OPEN_APP'
    | 'SEARCH_YOUTUBE'
    | 'DIAL_PHONE'
    | 'SEND_WHATSAPP'
    | 'OPEN_CAMERA'
    | 'SET_ALARM'
    | 'OPEN_SETTINGS'
    | 'NAVIGATE'
    | 'WEB_SEARCH';
  params: Record<string, string>;
  title: string;
  description: string;
  requiresConfirmation: boolean;
  isExecuted?: boolean;
}

export interface ChatMessage {
  id: string;
  role: Role;
  content: string;
  timestamp: number;
  image?: {
    data: string; // base64
    mimeType: string;
    previewUrl?: string;
  };
  actionIntent?: ActionIntent;
  groundingSources?: Array<{ uri?: string; title?: string }>;
  isStreaming?: boolean;
}

export interface AIFeatureItem {
  id: string;
  number: number;
  title: string;
  subtitle: string;
  category: 'Core Brain' | 'Creative' | 'STEM & Code' | 'Productivity' | 'Education';
  icon: string;
  badge?: string;
  defaultPrompt: string;
  systemHint?: string;
}

export interface AppSettings {
  apiKey: string;
  selectedModel: 'gemini-3.8-flash' | 'gemini-3.1-flash-lite' | 'gemini-4-argon';
  language: 'auto' | 'hi' | 'en' | 'hinglish';
  personality: 'helpful' | 'expert' | 'friendly' | 'concise' | 'coder';
  voiceSpeed: number;
  voicePitch: number;
  darkTheme: boolean;
  accessibilityServiceEnabled: boolean;
  confirmSensitiveActions: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: number;
  messages: ChatMessage[];
  category?: string;
}
