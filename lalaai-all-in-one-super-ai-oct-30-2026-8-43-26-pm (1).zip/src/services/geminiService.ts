import { ChatMessage, ActionIntent, AppSettings } from '../types';

export async function sendChatMessage(
  messages: ChatMessage[],
  settings: AppSettings,
  options?: { useSearchGrounding?: boolean }
): Promise<{ text: string; actionIntent?: ActionIntent; groundingSources?: Array<{ uri?: string; title?: string }> }> {
  const payload = {
    messages: messages.map((m) => ({
      role: m.role,
      content: m.content,
      image: m.image
        ? {
            data: m.image.data,
            mimeType: m.image.mimeType,
          }
        : undefined,
    })),
    options: {
      model: settings.selectedModel,
      language: settings.language,
      personality: settings.personality,
      useSearchGrounding: options?.useSearchGrounding,
      customApiKey: settings.apiKey || undefined,
    },
  };

  const res = await fetch('/api/gemini/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || `Error ${res.status}: Failed to generate AI response`);
  }

  const data = await res.json();
  const rawText = data.text || '';

  // Extract Action Intent if embedded in model response
  const { cleanText, actionIntent } = parseActionFromText(rawText);

  // Extract grounding sources if available
  const groundingSources: Array<{ uri?: string; title?: string }> = [];
  if (data.grounding?.chunks) {
    for (const chunk of data.grounding.chunks) {
      if (chunk.web?.uri) {
        groundingSources.push({
          uri: chunk.web.uri,
          title: chunk.web.title || chunk.web.uri,
        });
      }
    }
  }

  return {
    text: cleanText,
    actionIntent,
    groundingSources,
  };
}

export async function runAITool(
  feature: string,
  input: string,
  extraParams: Record<string, unknown> = {},
  settings: AppSettings
): Promise<{ text: string; grounding?: any }> {
  const payload = {
    feature,
    input,
    extraParams,
    options: {
      model: settings.selectedModel,
      language: settings.language,
      personality: settings.personality,
      customApiKey: settings.apiKey || undefined,
    },
  };

  const res = await fetch('/api/gemini/tool', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `Tool error: ${res.statusText}`);
  }

  return await res.json();
}

export async function executeDeviceIntent(
  actionIntent: ActionIntent,
  userConfirmed: boolean
): Promise<{ success: boolean; intentUri?: string; message?: string }> {
  const res = await fetch('/api/device/intent', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      actionType: actionIntent.type,
      params: actionIntent.params,
      userConfirmed,
    }),
  });

  const data = await res.json();
  return data;
}

export function parseActionFromText(text: string): { cleanText: string; actionIntent?: ActionIntent } {
  const regex = /\[ACTION:(.*?)\]/s;
  const match = text.match(regex);

  if (!match) {
    return { cleanText: text };
  }

  try {
    const jsonStr = match[1];
    const parsed = JSON.parse(jsonStr);
    const cleanText = text.replace(match[0], '').trim();

    const actionIntent: ActionIntent = {
      id: 'intent-' + Date.now(),
      type: parsed.type || 'OPEN_APP',
      params: parsed.params || {},
      title: parsed.title || getActionTitle(parsed.type, parsed.params),
      description: parsed.description || `Execute ${parsed.type}`,
      requiresConfirmation: true,
      isExecuted: false,
    };

    return { cleanText, actionIntent };
  } catch (e) {
    console.error('Failed to parse intent JSON:', e);
    return { cleanText: text };
  }
}

function getActionTitle(type: string, params: Record<string, string>): string {
  switch (type) {
    case 'OPEN_APP':
      return `Open App (${params?.target || params?.package || 'Application'})`;
    case 'SEARCH_YOUTUBE':
      return `Search YouTube for "${params?.query || ''}"`;
    case 'DIAL_PHONE':
      return `Dial Phone Number (${params?.number || params?.target || ''})`;
    case 'SEND_WHATSAPP':
      return `Send WhatsApp Message`;
    case 'OPEN_CAMERA':
      return `Launch Camera`;
    case 'OPEN_SETTINGS':
      return `Open Android Settings`;
    case 'NAVIGATE':
      return `Navigate to ${params?.location || params?.query || 'Location'}`;
    case 'WEB_SEARCH':
      return `Search Google for "${params?.query || ''}"`;
    default:
      return `Execute Android Action (${type})`;
  }
}
