import React from 'react';
import { ShieldAlert, ExternalLink, CheckCircle, X, Smartphone, Youtube, Phone, MessageSquare, Camera, Settings, MapPin, Globe } from 'lucide-react';
import { ActionIntent } from '../../types';

interface ActionConfirmationModalProps {
  intent: ActionIntent | null;
  onConfirm: (intent: ActionIntent) => void;
  onCancel: () => void;
}

export const ActionConfirmationModal: React.FC<ActionConfirmationModalProps> = ({
  intent,
  onConfirm,
  onCancel,
}) => {
  if (!intent) return null;

  const getIntentIcon = (type: string) => {
    switch (type) {
      case 'SEARCH_YOUTUBE':
        return <Youtube className="w-6 h-6 text-red-400" />;
      case 'DIAL_PHONE':
        return <Phone className="w-6 h-6 text-emerald-400" />;
      case 'SEND_WHATSAPP':
        return <MessageSquare className="w-6 h-6 text-emerald-400" />;
      case 'OPEN_CAMERA':
        return <Camera className="w-6 h-6 text-blue-400" />;
      case 'OPEN_SETTINGS':
        return <Settings className="w-6 h-6 text-amber-400" />;
      case 'NAVIGATE':
        return <MapPin className="w-6 h-6 text-rose-400" />;
      case 'WEB_SEARCH':
        return <Globe className="w-6 h-6 text-cyan-400" />;
      default:
        return <Smartphone className="w-6 h-6 text-purple-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-sm bg-slate-900 border border-purple-500/30 rounded-3xl p-6 shadow-2xl shadow-purple-950/50">
        {/* Security Badge */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400">
              <ShieldAlert className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">Android Security Confirmation</h3>
              <p className="text-[10px] text-purple-400 font-mono">Explicit User Consent Required</p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Intent Details */}
        <div className="my-5 p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3">
          <div className="flex items-start space-x-3">
            <div className="p-2.5 rounded-xl bg-slate-800/80 mt-0.5">
              {getIntentIcon(intent.type)}
            </div>
            <div className="flex-1">
              <div className="text-xs uppercase tracking-wider text-purple-300 font-semibold">
                Action: {intent.type}
              </div>
              <div className="text-sm font-medium text-slate-100 mt-0.5">
                {intent.title}
              </div>
              <div className="text-xs text-slate-400 mt-1">
                {intent.description}
              </div>
            </div>
          </div>

          {/* Parameters Table */}
          {Object.keys(intent.params).length > 0 && (
            <div className="pt-2 border-t border-slate-800/80 text-[11px] font-mono space-y-1">
              {Object.entries(intent.params).map(([key, val]) => (
                <div key={key} className="flex justify-between text-slate-400">
                  <span className="text-slate-500">{key}:</span>
                  <span className="text-slate-200 truncate max-w-[180px]">{val}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Safe Operating Disclaimer */}
        <p className="text-[11px] text-slate-400 leading-relaxed mb-5">
          🔒 LalaAI never secretly controls your device. Clicking confirm will trigger the official Android Intent to open the target application safely.
        </p>

        {/* Buttons */}
        <div className="flex space-x-3">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 px-4 rounded-xl border border-slate-700 bg-slate-800/50 hover:bg-slate-800 text-slate-300 font-medium text-xs transition-colors"
          >
            Decline / Cancel
          </button>
          <button
            onClick={() => onConfirm(intent)}
            className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-semibold text-xs shadow-lg shadow-purple-600/30 flex items-center justify-center space-x-1.5 transition-all"
          >
            <CheckCircle className="w-3.5 h-3.5" />
            <span>Confirm & Launch</span>
          </button>
        </div>
      </div>
    </div>
  );
};
