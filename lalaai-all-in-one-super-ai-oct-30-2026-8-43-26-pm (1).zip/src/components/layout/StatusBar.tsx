import React, { useState, useEffect } from 'react';
import { Wifi, Battery, Sparkles } from 'lucide-react';

export const StatusBar: React.FC = () => {
  const [time, setTime] = useState<string>('09:41');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full px-5 pt-3 pb-1 flex items-center justify-between text-xs font-medium text-slate-300 select-none z-30">
      <div className="flex items-center space-x-1.5">
        <span className="font-semibold tracking-tight text-slate-200">{time}</span>
        <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[9px] bg-purple-500/20 text-purple-300 font-mono border border-purple-500/30">
          <Sparkles className="w-2.5 h-2.5 mr-0.5 text-purple-400 animate-pulse" />
          5G+
        </span>
      </div>

      {/* Dynamic Island / Camera Notch */}
      <div className="w-20 h-4 bg-slate-900 rounded-full flex items-center justify-center border border-slate-800/80 shadow-inner">
        <div className="w-2 h-2 rounded-full bg-slate-950 border border-slate-800" />
      </div>

      <div className="flex items-center space-x-2 text-slate-400">
        <Wifi className="w-3.5 h-3.5 text-slate-300" />
        <div className="flex items-center space-x-1">
          <span className="text-[10px]">98%</span>
          <Battery className="w-4 h-4 text-emerald-400" />
        </div>
      </div>
    </div>
  );
};
