import React from 'react';
import { Home, MessageSquare, LayoutGrid, Clock, Settings, CodeXml } from 'lucide-react';

export type TabType = 'home' | 'chat' | 'explore' | 'history' | 'settings' | 'android-studio';

interface BottomNavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'home' as TabType, label: 'Home', icon: Home },
    { id: 'chat' as TabType, label: 'AI Chat', icon: MessageSquare, badge: 'Live' },
    { id: 'explore' as TabType, label: 'Explore', icon: LayoutGrid, count: '20' },
    { id: 'history' as TabType, label: 'History', icon: Clock },
    { id: 'settings' as TabType, label: 'Settings', icon: Settings },
  ];

  return (
    <div className="w-full bg-slate-900/95 backdrop-blur-xl border-t border-slate-800/80 px-2 py-1.5 flex items-center justify-around z-30 select-none shadow-2xl">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;

        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all duration-200 cursor-pointer ${
              isActive
                ? 'text-purple-400 scale-105'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            {/* Active Glow Pill */}
            {isActive && (
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/15 to-blue-500/15 rounded-2xl border border-purple-500/30 -z-10" />
            )}

            <div className="relative">
              <Icon className={`w-5 h-5 transition-transform duration-200 ${isActive ? 'stroke-[2.5px]' : 'stroke-2'}`} />
              {tab.badge && (
                <span className="absolute -top-1 -right-2 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-slate-900 animate-pulse" />
              )}
              {tab.count && (
                <span className="absolute -top-1.5 -right-3 px-1 py-0.2 bg-purple-600 text-[8px] font-bold text-white rounded-full">
                  {tab.count}
                </span>
              )}
            </div>

            <span className={`text-[10px] mt-1 font-medium tracking-tight ${isActive ? 'font-bold text-purple-300' : ''}`}>
              {tab.label}
            </span>
          </button>
        );
      })}

      {/* Direct Shortcut to Android Studio Workbench */}
      <button
        onClick={() => onTabChange('android-studio')}
        title="View Kotlin Project & Build APK"
        className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-2xl transition-all cursor-pointer ${
          activeTab === 'android-studio'
            ? 'text-cyan-400 bg-cyan-500/15 border border-cyan-500/30'
            : 'text-cyan-400/70 hover:text-cyan-300 hover:bg-slate-800/40'
        }`}
      >
        <CodeXml className="w-5 h-5" />
        <span className="text-[10px] mt-1 font-medium">APK Code</span>
      </button>
    </div>
  );
};
