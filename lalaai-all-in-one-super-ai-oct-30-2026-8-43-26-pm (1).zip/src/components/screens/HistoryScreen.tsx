import React, { useState } from 'react';
import {
  Clock,
  Search,
  MessageCircle,
  Trash2,
  Download,
  Bookmark,
  Share2,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { ChatSession } from '../../types';

interface HistoryScreenProps {
  sessions: ChatSession[];
  onSelectSession: (session: ChatSession) => void;
  onClearAll: () => void;
  onDeleteSession: (sessionId: string) => void;
}

export const HistoryScreen: React.FC<HistoryScreenProps> = ({
  sessions,
  onSelectSession,
  onClearAll,
  onDeleteSession,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'chats' | 'favorites'>('chats');

  const savedPrompts = [
    { title: 'Explain Quantum Computing in Hindi', category: 'Education', prompt: 'नमस्ते लाला! क्वांटम कंप्यूटिंग को बहुत सरल हिन्दी में उदाहरण के साथ समझाओ।' },
    { title: 'Kotlin StateFlow Architecture Pattern', category: 'STEM', prompt: 'Write a complete Android Jetpack Compose ViewModel with Kotlin StateFlow, error handling, and coroutines.' },
    { title: 'Executive Cold Pitch Email', category: 'Productivity', prompt: 'Write 3 compelling subject lines and a concise 120-word cold pitch email offering enterprise AI solutions.' },
    { title: 'Google Veo Cinematic Video Prompt', category: 'Creative', prompt: 'Generate an ultra-detailed cinematic 4K Google Veo video generation prompt with camera panning and golden hour lighting.' },
  ];

  const filteredSessions = sessions.filter(
    (s) =>
      s.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.lastMessage.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 pb-20 custom-scrollbar">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-100">Conversation Memory</h2>
          <p className="text-xs text-slate-400">Search past chats, stored queries & saved favorites</p>
        </div>

        {sessions.length > 0 && (
          <button
            onClick={onClearAll}
            className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-slate-900 transition-colors"
            title="Clear All Conversations"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex rounded-2xl bg-slate-900 p-1 border border-slate-800">
        <button
          onClick={() => setActiveTab('chats')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
            activeTab === 'chats'
              ? 'bg-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Recent Chats ({sessions.length})
        </button>
        <button
          onClick={() => setActiveTab('favorites')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
            activeTab === 'favorites'
              ? 'bg-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Saved Prompts (4)
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search chat topics or messages..."
          className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-200 placeholder-slate-500 outline-none focus:border-purple-500/50"
        />
      </div>

      {/* Sessions List */}
      {activeTab === 'chats' ? (
        filteredSessions.length === 0 ? (
          <div className="py-12 text-center space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-slate-500">
              <Clock className="w-6 h-6" />
            </div>
            <p className="text-xs text-slate-400">No previous chat sessions found.</p>
            <p className="text-[11px] text-slate-500">Start a new conversation with LalaAI to save history.</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {filteredSessions.map((session) => (
              <div
                key={session.id}
                className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-purple-500/30 flex items-center justify-between group transition-all"
              >
                <div
                  onClick={() => onSelectSession(session)}
                  className="flex-1 flex items-start space-x-3 cursor-pointer overflow-hidden"
                >
                  <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 mt-0.5 shrink-0">
                    <MessageCircle className="w-4 h-4" />
                  </div>
                  <div className="overflow-hidden">
                    <h4 className="text-xs font-bold text-slate-200 truncate group-hover:text-purple-300">
                      {session.title}
                    </h4>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">
                      {session.lastMessage}
                    </p>
                    <span className="text-[10px] text-slate-500 font-mono mt-1 block">
                      {new Date(session.timestamp).toLocaleDateString()} • {new Date(session.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>

                <div className="flex items-center space-x-1 shrink-0 ml-2">
                  <button
                    onClick={() => onDeleteSession(session.id)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onSelectSession(session)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-purple-400 hover:bg-slate-800 transition-colors"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        /* Saved Prompts */
        <div className="space-y-2.5">
          {savedPrompts.map((item, idx) => (
            <div
              key={idx}
              className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-purple-500/30 space-y-1.5"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200">{item.title}</span>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-medium">
                  {item.category}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 italic">"{item.prompt}"</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
