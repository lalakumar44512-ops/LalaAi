import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Mic,
  MicOff,
  Camera,
  Image as ImageIcon,
  Paperclip,
  Volume2,
  VolumeX,
  Copy,
  Check,
  Trash2,
  Download,
  Share2,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  Play,
  RotateCcw
} from 'lucide-react';
import { ChatMessage, ActionIntent, AppSettings } from '../../types';
import { voiceManager } from '../../services/voiceService';

interface ChatScreenProps {
  messages: ChatMessage[];
  isLoading: boolean;
  onSendMessage: (text: string, image?: { data: string; mimeType: string }) => void;
  onClearChat: () => void;
  onExecuteIntent: (intent: ActionIntent) => void;
  onOpenCamera: () => void;
  settings: AppSettings;
}

export const ChatScreen: React.FC<ChatScreenProps> = ({
  messages,
  isLoading,
  onSendMessage,
  onClearChat,
  onExecuteIntent,
  onOpenCamera,
  settings,
}) => {
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [activeSpeechId, setActiveSpeechId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [attachedImage, setAttachedImage] = useState<{ data: string; mimeType: string; preview: string } | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSend = () => {
    if (!inputText.trim() && !attachedImage) return;

    onSendMessage(
      inputText.trim(),
      attachedImage ? { data: attachedImage.data, mimeType: attachedImage.mimeType } : undefined
    );

    setInputText('');
    setAttachedImage(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setAttachedImage({
        data: result,
        mimeType: file.type || 'image/jpeg',
        preview: result,
      });
    };
    reader.readAsDataURL(file);
  };

  const toggleVoiceRecording = () => {
    if (isRecording) {
      voiceManager.stopListening();
      setIsRecording(false);
    } else {
      setIsRecording(true);
      voiceManager.startListening(
        settings.language === 'hi' ? 'hi-IN' : 'en-US',
        (text, isFinal) => {
          setInputText(text);
          if (isFinal) {
            setIsRecording(false);
          }
        },
        (error) => {
          console.error('Voice error:', error);
          setIsRecording(false);
        },
        () => {
          setIsRecording(false);
        }
      );
    }
  };

  const handleSpeak = (id: string, text: string) => {
    if (activeSpeechId === id) {
      voiceManager.stopSpeaking();
      setActiveSpeechId(null);
    } else {
      setActiveSpeechId(id);
      voiceManager.speak(text, settings.voiceSpeed, settings.voicePitch, () => {
        setActiveSpeechId(null);
      });
    }
  };

  const copyToClipboard = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const exportConversation = () => {
    const markdown = messages
      .map((m) => `### ${m.role === 'user' ? '👤 User' : '🤖 LalaAI'}\n\n${m.content}\n\n---\n`)
      .join('\n');
    const blob = new Blob([markdown], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `LalaAI-Chat-${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden">
      {/* Chat Top Bar */}
      <div className="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-2.5">
          <div className="relative">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 to-blue-500 flex items-center justify-center text-white font-bold text-sm shadow-md">
              L
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border border-slate-900" />
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="text-xs font-bold text-slate-100">LalaAI Chat Brain</span>
              <span className="text-[10px] font-mono text-purple-400 bg-purple-500/10 px-1.5 py-0.2 rounded border border-purple-500/20">
                {settings.selectedModel}
              </span>
            </div>
            <span className="text-[10px] text-slate-400">Hindi • English • Vision Multimodal</span>
          </div>
        </div>

        <div className="flex items-center space-x-1">
          <button
            onClick={exportConversation}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            title="Export Markdown"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={onClearChat}
            className="p-1.5 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
            title="Clear Chat"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} space-y-1`}
            >
              {/* Message Bubble */}
              <div
                className={`relative max-w-[88%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed ${
                  isUser
                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-900/20 rounded-br-sm'
                    : 'bg-slate-900 border border-slate-800 text-slate-100 shadow-md rounded-bl-sm'
                }`}
              >
                {/* Attached Image if present */}
                {msg.image && (
                  <div className="mb-2.5 rounded-xl overflow-hidden border border-white/10 max-h-48">
                    <img
                      src={msg.image.data.startsWith('data:') ? msg.image.data : `data:${msg.image.mimeType};base64,${msg.image.data}`}
                      alt="Uploaded"
                      className="w-full h-auto object-cover"
                    />
                  </div>
                )}

                {/* Formatted Text Content */}
                <div className="whitespace-pre-wrap break-words font-sans">
                  {msg.content}
                </div>

                {/* Search Grounding Sources */}
                {msg.groundingSources && msg.groundingSources.length > 0 && (
                  <div className="mt-2.5 pt-2 border-t border-slate-800 text-[10px] space-y-1">
                    <div className="flex items-center space-x-1 text-cyan-400 font-semibold">
                      <ExternalLink className="w-3 h-3" />
                      <span>Google Search Grounded Sources:</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {msg.groundingSources.map((source, i) => (
                        <a
                          key={i}
                          href={source.uri}
                          target="_blank"
                          rel="noreferrer"
                          className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-300 hover:text-cyan-300 hover:border-cyan-500/30 truncate max-w-[200px]"
                        >
                          {source.title || source.uri}
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                {/* Assistant Controls: TTS & Copy */}
                {!isUser && (
                  <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="text-[10px] text-slate-500 font-mono">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <div className="flex items-center space-x-1.5">
                      <button
                        onClick={() => handleSpeak(msg.id, msg.content)}
                        className={`p-1 rounded-lg hover:bg-slate-800 transition-colors ${
                          activeSpeechId === msg.id ? 'text-cyan-400 bg-cyan-500/10' : 'text-slate-400'
                        }`}
                        title="Read Aloud in Hindi/English"
                      >
                        {activeSpeechId === msg.id ? (
                          <VolumeX className="w-3.5 h-3.5 animate-pulse" />
                        ) : (
                          <Volume2 className="w-3.5 h-3.5" />
                        )}
                      </button>
                      <button
                        onClick={() => copyToClipboard(msg.id, msg.content)}
                        className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
                        title="Copy text"
                      >
                        {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Action Intent Card (if LalaAI proposed an Android Phone Action) */}
              {msg.actionIntent && (
                <div className="w-full max-w-[88%] mt-1.5 p-3 rounded-2xl bg-gradient-to-r from-purple-950/70 via-slate-900 to-slate-900 border border-purple-500/40 shadow-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <ShieldCheck className="w-4 h-4 text-purple-400" />
                      <span className="text-xs font-bold text-purple-200">Android Intent Trigger</span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">{msg.actionIntent.type}</span>
                  </div>

                  <p className="text-xs font-medium text-slate-200 mt-1">
                    {msg.actionIntent.title}
                  </p>

                  <div className="mt-2.5 flex items-center justify-between">
                    <span className="text-[10px] text-slate-400">
                      {msg.actionIntent.isExecuted ? '✓ Successfully executed' : 'Requires your approval'}
                    </span>
                    <button
                      onClick={() => onExecuteIntent(msg.actionIntent!)}
                      disabled={msg.actionIntent.isExecuted}
                      className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 disabled:opacity-50 text-white text-xs font-semibold shadow-md shadow-purple-600/30 flex items-center space-x-1 cursor-pointer"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>{msg.actionIntent.isExecuted ? 'Executed' : 'Execute Action'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex items-center space-x-2 p-3 rounded-2xl bg-slate-900 border border-slate-800 text-slate-400 text-xs w-max animate-pulse">
            <Sparkles className="w-4 h-4 text-purple-400 animate-spin" />
            <span>LalaAI is thinking and generating response...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Voice Listening Overlay Bar */}
      {isRecording && (
        <div className="px-4 py-2 bg-gradient-to-r from-purple-900/80 to-blue-900/80 border-t border-purple-500/30 flex items-center justify-between animate-pulse">
          <div className="flex items-center space-x-2 text-xs text-purple-200 font-medium">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
            <span>Listening to voice in {settings.language === 'hi' ? 'Hindi (हिन्दी)' : 'English'}... Speak now</span>
          </div>
          <button
            onClick={toggleVoiceRecording}
            className="px-2.5 py-1 rounded-lg bg-rose-600 text-white text-[11px] font-semibold hover:bg-rose-500"
          >
            Stop
          </button>
        </div>
      )}

      {/* Attached Image Preview */}
      {attachedImage && (
        <div className="px-4 py-2 bg-slate-900 border-t border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src={attachedImage.preview} alt="Attachment" className="w-9 h-9 rounded-lg object-cover border border-purple-500/40" />
            <span className="text-xs text-slate-300">Ready for Multimodal Gemini Vision</span>
          </div>
          <button
            onClick={() => setAttachedImage(null)}
            className="text-xs text-rose-400 hover:text-rose-300 font-medium"
          >
            Remove
          </button>
        </div>
      )}

      {/* Bottom Input Field */}
      <div className="p-3 bg-slate-900/90 border-t border-slate-800 shrink-0">
        <div className="relative flex items-center bg-slate-950 rounded-2xl border border-slate-800 focus-within:border-purple-500/60 p-1.5 shadow-inner">
          {/* File Upload Hidden Input */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*,application/pdf"
            className="hidden"
          />

          <div className="flex items-center space-x-1 pl-1">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-2 rounded-xl text-slate-400 hover:text-purple-400 hover:bg-slate-900 transition-colors"
              title="Upload Image/Document"
            >
              <Paperclip className="w-4 h-4" />
            </button>
            <button
              onClick={onOpenCamera}
              className="p-2 rounded-xl text-slate-400 hover:text-blue-400 hover:bg-slate-900 transition-colors"
              title="Open Camera"
            >
              <Camera className="w-4 h-4" />
            </button>
            <button
              onClick={toggleVoiceRecording}
              className={`p-2 rounded-xl transition-colors ${
                isRecording
                  ? 'bg-rose-600 text-white animate-pulse'
                  : 'text-slate-400 hover:text-cyan-400 hover:bg-slate-900'
              }`}
              title="Voice Assistant Speech-to-Text"
            >
              <Mic className="w-4 h-4" />
            </button>
          </div>

          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Type message or ask in Hindi/English..."
            rows={1}
            className="flex-1 bg-transparent text-xs sm:text-sm text-slate-100 placeholder-slate-500 outline-none px-3 py-1.5 resize-none max-h-24"
          />

          <button
            onClick={handleSend}
            disabled={!inputText.trim() && !attachedImage}
            className="p-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white disabled:opacity-30 transition-all shadow-md shadow-purple-600/30 shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
