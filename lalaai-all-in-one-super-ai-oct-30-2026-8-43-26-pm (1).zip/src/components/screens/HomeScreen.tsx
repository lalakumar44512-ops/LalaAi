import React, { useState } from 'react';
import {
  Sparkles,
  Mic,
  Camera,
  Send,
  Settings as SettingsIcon,
  Play,
  MessageCircle,
  Code2,
  Search,
  Languages,
  Calculator,
  Compass,
  ArrowRight,
  ShieldCheck,
  Zap,
  Volume2
} from 'lucide-react';
import { AIFeatureItem, ChatSession, AppSettings } from '../../types';

interface HomeScreenProps {
  onNavigate: (tab: any) => void;
  onSelectFeature: (feature: AIFeatureItem) => void;
  onSendQuickPrompt: (prompt: string, image?: string) => void;
  recentSessions: ChatSession[];
  settings: AppSettings;
  onOpenVoice: () => void;
  onOpenCamera: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigate,
  onSelectFeature,
  onSendQuickPrompt,
  recentSessions,
  settings,
  onOpenVoice,
  onOpenCamera,
}) => {
  const [quickText, setQuickText] = useState('');

  const quickPrompts = [
    { label: '🇮🇳 हिन्दी में समझाओ', prompt: 'नमस्ते लाला! क्वांटम कंप्यूटिंग को बहुत सरल हिन्दी में समझाओ।' },
    { label: '⚡ Fix Python Bug', prompt: 'Find the bug in this Python asynchronous loop code and optimize it.' },
    { label: '📺 Open YouTube', prompt: 'Open YouTube and search latest science and AI advancements.' },
    { label: '📐 Solve Calculus Math', prompt: 'Solve step-by-step: Find the derivative of f(x) = (3x^2 + 5)^4 * ln(x).' },
    { label: '✉️ Professional Email', prompt: 'Write a persuasive, polite follow-up email after an executive job interview.' },
    { label: '🎬 Viral Video Script', prompt: 'Generate a high-retention 60-second YouTube Shorts script about the future of AI.' },
  ];

  const featuredTools: AIFeatureItem[] = [
    {
      id: 'chat',
      number: 1,
      title: 'AI Chat Assistant',
      subtitle: 'Multi-turn reasoning in Hindi & English',
      category: 'Core Brain',
      icon: 'chat',
      defaultPrompt: 'Hello LalaAI! Let us explore your super intelligence.',
    },
    {
      id: 'voice',
      number: 2,
      title: 'Voice Assistant',
      subtitle: 'Real-time speech dialogue & TTS',
      category: 'Core Brain',
      icon: 'mic',
      defaultPrompt: 'Start voice conversation with LalaAI.',
    },
    {
      id: 'code',
      number: 5,
      title: 'AI Coding Assistant',
      subtitle: 'Full-stack Kotlin, Python & Web architecture',
      category: 'STEM & Code',
      icon: 'code',
      defaultPrompt: 'Write a complete Android Jetpack Compose ViewModel with Kotlin StateFlow.',
    },
    {
      id: 'search',
      number: 6,
      title: 'AI Web Search Grounding',
      subtitle: 'Real-time Google Search with cited sources',
      category: 'Core Brain',
      icon: 'search',
      defaultPrompt: 'Search the latest breakthroughs in space exploration and give key takeaways.',
    },
    {
      id: 'translate',
      number: 7,
      title: 'AI Translator',
      subtitle: 'Natural Hindi <-> English & 50+ languages',
      category: 'Productivity',
      icon: 'translate',
      defaultPrompt: 'Translate: "The future belongs to those who prepare for it today" into pure Hindi with pronunciation.',
    },
    {
      id: 'math',
      number: 12,
      title: 'AI Math Solver',
      subtitle: 'Algebra, calculus & step-by-step logic',
      category: 'STEM & Code',
      icon: 'calculator',
      defaultPrompt: 'Solve step-by-step: Integrate (3x^2 + 2x) dx from 1 to 4 with formula breakdown.',
    },
  ];

  const handleSend = () => {
    if (quickText.trim()) {
      onSendQuickPrompt(quickText.trim());
      setQuickText('');
    }
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-5 pb-20 custom-scrollbar">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-blue-500 flex items-center justify-center shadow-lg shadow-purple-600/30 border border-purple-400/30">
              <span className="text-xl font-black text-white tracking-tighter">L</span>
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-slate-950 animate-pulse" />
          </div>

          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-bold text-slate-100 tracking-tight">LalaAI</h1>
              <span className="px-1.5 py-0.5 rounded-md bg-purple-500/20 text-purple-300 text-[10px] font-mono border border-purple-500/30">
                Super AI v2.5
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {settings.language === 'hi'
                ? 'हिन्दी और अंग्रेजी में स्मार्ट सहायक'
                : settings.language === 'hinglish'
                ? 'Smart Assistant in Hinglish & English'
                : 'All-in-One Super Android AI Assistant'}
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigate('settings')}
          className="p-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-purple-400 hover:border-purple-500/30 transition-all cursor-pointer shadow-sm"
          title="App Settings"
        >
          <SettingsIcon className="w-5 h-5" />
        </button>
      </div>

      {/* Hero AI Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-purple-900/60 via-slate-900 to-slate-950 border border-purple-500/30 p-5 shadow-xl shadow-purple-950/40">
        <div className="absolute top-0 right-0 -mt-6 -mr-6 w-36 h-36 bg-purple-500/20 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-6 -ml-6 w-32 h-32 bg-blue-500/15 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10 space-y-2.5">
          <div className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-purple-500/20 border border-purple-500/30 text-purple-300 text-xs font-medium">
            <Zap className="w-3.5 h-3.5 text-purple-400" />
            <span>Google Gemini 3.8 Powered Engine</span>
          </div>

          <h2 className="text-lg font-extrabold text-white tracking-tight leading-snug">
            {settings.language === 'hi'
              ? 'नमस्ते! मैं LalaAI हूँ – आज क्या बनाना या हल करना चाहते हैं?'
              : 'Namaste! I am LalaAI – your all-in-one super intelligence.'}
          </h2>

          <p className="text-xs text-slate-300 leading-relaxed">
            20 AI Superpowers built-in • Fluent Hindi & English • Android Intent Control with safe user confirmation • Live Web Search Grounding.
          </p>

          <div className="pt-1 flex items-center space-x-2">
            <button
              onClick={onOpenVoice}
              className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-md shadow-purple-600/30 transition-all cursor-pointer"
            >
              <Mic className="w-3.5 h-3.5" />
              <span>Voice Mode</span>
            </button>
            <button
              onClick={() => onNavigate('explore')}
              className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-medium transition-all cursor-pointer"
            >
              <Compass className="w-3.5 h-3.5 text-cyan-400" />
              <span>Explore 20 Tools</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Input Box */}
      <div className="relative rounded-2xl bg-slate-900 border border-slate-800 focus-within:border-purple-500/60 p-2 transition-all shadow-lg">
        <textarea
          value={quickText}
          onChange={(e) => setQuickText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleSend();
            }
          }}
          placeholder="Ask LalaAI anything in Hindi or English, or request phone action..."
          rows={2}
          className="w-full bg-transparent text-sm text-slate-100 placeholder-slate-500 resize-none outline-none px-2 pt-1"
        />

        <div className="flex items-center justify-between pt-1 border-t border-slate-800/60 px-1">
          <div className="flex items-center space-x-1.5">
            <button
              onClick={onOpenVoice}
              className="p-2 rounded-xl text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition-colors"
              title="Voice Input"
            >
              <Mic className="w-4 h-4" />
            </button>
            <button
              onClick={onOpenCamera}
              className="p-2 rounded-xl text-slate-400 hover:text-blue-400 hover:bg-slate-800 transition-colors"
              title="Camera Scan"
            >
              <Camera className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={handleSend}
            disabled={!quickText.trim()}
            className="p-2 rounded-xl bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white disabled:opacity-40 transition-all shadow-md shadow-purple-600/30"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Quick Prompt Chips */}
      <div>
        <div className="flex items-center justify-between text-xs font-semibold text-slate-400 mb-2 px-1">
          <span>Quick Inspiration</span>
          <span className="text-[10px] text-purple-400">Hindi & English Ready</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {quickPrompts.map((chip, idx) => (
            <button
              key={idx}
              onClick={() => onSendQuickPrompt(chip.prompt)}
              className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800/90 hover:border-purple-500/40 text-xs text-slate-300 hover:text-purple-300 transition-all text-left flex items-center space-x-1 shadow-sm"
            >
              <span>{chip.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Android Phone Control Shortcuts */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold text-slate-200">Android Phone Intent Actions</span>
          </div>
          <span className="text-[10px] text-slate-400">Explicit Permission Guard</span>
        </div>

        <div className="grid grid-cols-4 gap-2 text-center">
          <button
            onClick={() => onSendQuickPrompt('Open YouTube and search latest tech documentaries')}
            className="p-2.5 rounded-xl bg-slate-950/80 hover:bg-purple-950/30 border border-slate-800 hover:border-purple-500/30 flex flex-col items-center justify-center transition-all group"
          >
            <div className="w-8 h-8 rounded-lg bg-red-500/15 flex items-center justify-center text-red-400 group-hover:scale-110 transition-transform">
              <Play className="w-4 h-4 fill-current" />
            </div>
            <span className="text-[10px] font-medium text-slate-300 mt-1.5">YouTube</span>
          </button>

          <button
            onClick={() => onSendQuickPrompt('Open WhatsApp to message colleagues')}
            className="p-2.5 rounded-xl bg-slate-950/80 hover:bg-purple-950/30 border border-slate-800 hover:border-purple-500/30 flex flex-col items-center justify-center transition-all group"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-500/15 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
              <MessageCircle className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-medium text-slate-300 mt-1.5">WhatsApp</span>
          </button>

          <button
            onClick={onOpenCamera}
            className="p-2.5 rounded-xl bg-slate-950/80 hover:bg-purple-950/30 border border-slate-800 hover:border-purple-500/30 flex flex-col items-center justify-center transition-all group"
          >
            <div className="w-8 h-8 rounded-lg bg-blue-500/15 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
              <Camera className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-medium text-slate-300 mt-1.5">Camera</span>
          </button>

          <button
            onClick={() => onSendQuickPrompt('Search Google for today weather forecast and news')}
            className="p-2.5 rounded-xl bg-slate-950/80 hover:bg-purple-950/30 border border-slate-800 hover:border-purple-500/30 flex flex-col items-center justify-center transition-all group"
          >
            <div className="w-8 h-8 rounded-lg bg-cyan-500/15 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
              <Search className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-medium text-slate-300 mt-1.5">Web Search</span>
          </button>
        </div>
      </div>

      {/* Featured AI Superpowers (Explore 20 Tools) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-200">AI Superpowers (20 Features)</h3>
          <button
            onClick={() => onNavigate('explore')}
            className="text-xs font-semibold text-purple-400 hover:text-purple-300 flex items-center space-x-1"
          >
            <span>View All (20)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {featuredTools.map((tool) => (
            <div
              key={tool.id}
              onClick={() => onSelectFeature(tool)}
              className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-purple-500/40 hover:bg-slate-850 transition-all cursor-pointer group shadow-sm flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="px-2 py-0.5 rounded-lg bg-purple-500/15 text-purple-300 text-[10px] font-mono font-bold">
                    #{tool.number}
                  </span>
                  <span className="text-[10px] text-slate-500 font-medium">{tool.category}</span>
                </div>
                <h4 className="text-xs font-bold text-slate-100 group-hover:text-purple-300 transition-colors">
                  {tool.title}
                </h4>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {tool.subtitle}
                </p>
              </div>

              <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-800/60">
                <span className="text-[10px] text-purple-400 font-medium">Launch Tool</span>
                <ArrowRight className="w-3 h-3 text-purple-400 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Conversations */}
      {recentSessions.length > 0 && (
        <div className="space-y-2.5">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-400">
            <span>Recent Chats</span>
            <button onClick={() => onNavigate('history')} className="text-purple-400 hover:underline">
              History
            </button>
          </div>

          <div className="space-y-2">
            {recentSessions.slice(0, 3).map((session) => (
              <div
                key={session.id}
                onClick={() => onNavigate('chat')}
                className="p-3 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-slate-700 flex items-center justify-between transition-colors cursor-pointer"
              >
                <div className="flex items-center space-x-3 overflow-hidden">
                  <div className="p-2 rounded-xl bg-purple-500/15 text-purple-400 shrink-0">
                    <MessageCircle className="w-4 h-4" />
                  </div>
                  <div className="overflow-hidden">
                    <div className="text-xs font-semibold text-slate-200 truncate">{session.title}</div>
                    <div className="text-[11px] text-slate-400 truncate">{session.lastMessage}</div>
                  </div>
                </div>
                <span className="text-[10px] text-slate-500 shrink-0 ml-2">
                  {new Date(session.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
