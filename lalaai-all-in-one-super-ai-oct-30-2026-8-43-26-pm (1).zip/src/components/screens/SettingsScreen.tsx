import React, { useState, useEffect } from 'react';
import {
  Key,
  Cpu,
  Languages,
  Shield,
  Volume2,
  Trash2,
  Info,
  CheckCircle,
  Eye,
  EyeOff,
  Sparkles,
  Sliders,
  Moon,
  Sun,
  Lock,
  CodeXml
} from 'lucide-react';
import { AppSettings } from '../../types';
import { voiceManager } from '../../services/voiceService';

interface SettingsScreenProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onClearChatHistory: () => void;
  onNavigateToStudio: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  settings,
  onUpdateSettings,
  onClearChatHistory,
  onNavigateToStudio,
}) => {
  const [apiKeyInput, setApiKeyInput] = useState(settings.apiKey);
  const [showKey, setShowKey] = useState(false);
  const [serverKeyStatus, setServerKeyStatus] = useState<boolean | null>(null);
  const [testSpeechPlaying, setTestSpeechPlaying] = useState(false);

  useEffect(() => {
    fetch('/api/status')
      .then((res) => res.json())
      .then((data) => {
        setServerKeyStatus(data.hasApiKey);
      })
      .catch(() => setServerKeyStatus(false));
  }, []);

  const models: Array<{ id: AppSettings['selectedModel']; name: string; tag: string; desc: string }> = [
    {
      id: 'gemini-3.8-flash',
      name: 'Gemini 3.8 Flash',
      tag: 'Default • Recommended',
      desc: 'Blazing fast, balanced reasoning, image vision understanding, Hindi & English mastery.',
    },
    {
      id: 'gemini-3.1-flash-lite',
      name: 'Gemini 3.1 Flash Lite',
      tag: 'Ultra-Low Latency',
      desc: 'Optimized for high-speed instant replies, quick commands, and lower resource usage.',
    },
    {
      id: 'gemini-4-argon',
      name: 'Gemini 4 Argon',
      tag: 'Deep Reasoning',
      desc: 'Heavy STEM reasoning, advanced mathematical proofs, and complex software design.',
    },
  ];

  const languages: Array<{ id: AppSettings['language']; name: string; native: string }> = [
    { id: 'auto', name: 'Auto-Detect', native: 'Detect user language dynamically' },
    { id: 'hi', name: 'Hindi', native: 'हिन्दी (Devanagari script)' },
    { id: 'hinglish', name: 'Hinglish', native: 'Hindi in Roman/English script (Casual)' },
    { id: 'en', name: 'English', native: 'Crisp & Professional English' },
  ];

  const handleSaveApiKey = () => {
    onUpdateSettings({ apiKey: apiKeyInput.trim() });
  };

  const testVoice = () => {
    setTestSpeechPlaying(true);
    const testText =
      settings.language === 'hi'
        ? 'नमस्ते! मैं LalaAI हूँ। आपकी आवाज़ बहुत अच्छी है।'
        : 'Hello! I am LalaAI, your super AI Android assistant.';
    voiceManager.speak(testText, settings.voiceSpeed, settings.voicePitch, () => {
      setTestSpeechPlaying(false);
    });
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-5 pb-20 custom-scrollbar">
      {/* Header */}
      <div>
        <h2 className="text-lg font-bold text-slate-100">LalaAI Settings</h2>
        <p className="text-xs text-slate-400">Configure AI models, bilingual intelligence & device safety</p>
      </div>

      {/* Gemini Engine & API Key */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 space-y-3 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-purple-500/15 text-purple-400">
              <Key className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-200">Google Gemini API Key</h3>
              <p className="text-[10px] text-slate-400">Primary AI engine authorization</p>
            </div>
          </div>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-semibold ${
              serverKeyStatus || settings.apiKey
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
            }`}
          >
            {serverKeyStatus || settings.apiKey ? '● Ready / Active' : '● Needs Key'}
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs space-y-1.5">
          <div className="flex items-center space-x-1.5 text-emerald-400 font-semibold text-[11px]">
            <CheckCircle className="w-3.5 h-3.5" />
            <span>AI Studio Environment Key Connected</span>
          </div>
          <p className="text-[11px] text-slate-400">
            LalaAI automatically leverages the runtime server key securely injected into the environment. You can also supply a personal test key below if desired.
          </p>
        </div>

        <div className="space-y-1.5">
          <label className="text-[11px] font-medium text-slate-400">Custom Gemini API Key (Optional Override):</label>
          <div className="relative flex items-center">
            <input
              type={showKey ? 'text' : 'password'}
              value={apiKeyInput}
              onChange={(e) => setApiKeyInput(e.target.value)}
              placeholder="Paste custom AIzaSy... key"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 placeholder-slate-600 outline-none focus:border-purple-500/50 pr-16"
            />
            <div className="absolute right-2 flex items-center space-x-1">
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="p-1 text-slate-400 hover:text-white"
              >
                {showKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
              <button
                type="button"
                onClick={handleSaveApiKey}
                className="px-2 py-1 rounded-lg bg-purple-600 text-white text-[10px] font-semibold hover:bg-purple-500"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Model Selection */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 space-y-3 shadow-sm">
        <div className="flex items-center space-x-2">
          <div className="p-2 rounded-xl bg-blue-500/15 text-blue-400">
            <Cpu className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-200">AI Model Brain</h3>
            <p className="text-[10px] text-slate-400">Choose preferred Gemini generation engine</p>
          </div>
        </div>

        <div className="space-y-2">
          {models.map((m) => {
            const isSelected = settings.selectedModel === m.id;
            return (
              <div
                key={m.id}
                onClick={() => onUpdateSettings({ selectedModel: m.id })}
                className={`p-3 rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-purple-950/40 border-purple-500/60 shadow-sm'
                    : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200">{m.name}</span>
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-mono">
                    {m.tag}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{m.desc}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Language Selection */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 space-y-3 shadow-sm">
        <div className="flex items-center space-x-2">
          <div className="p-2 rounded-xl bg-cyan-500/15 text-cyan-400">
            <Languages className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-200">Language & Cultural Tone</h3>
            <p className="text-[10px] text-slate-400">Hindi, Hinglish & English preferences</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {languages.map((l) => {
            const isSelected = settings.language === l.id;
            return (
              <button
                key={l.id}
                onClick={() => onUpdateSettings({ language: l.id })}
                className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-cyan-950/40 border-cyan-500/60'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="text-xs font-bold text-slate-200">{l.name}</div>
                <div className="text-[10px] text-slate-400 truncate mt-0.5">{l.native}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Voice & TTS Settings */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 space-y-3 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-rose-500/15 text-rose-400">
              <Volume2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-200">Voice & Speech Rate</h3>
              <p className="text-[10px] text-slate-400">Adjust TTS playback speed & pitch</p>
            </div>
          </div>
          <button
            onClick={testVoice}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-purple-300 font-medium"
          >
            {testSpeechPlaying ? 'Playing...' : 'Test Voice'}
          </button>
        </div>

        <div className="space-y-3 pt-1">
          <div>
            <div className="flex justify-between text-[11px] text-slate-300 mb-1">
              <span>Speech Speed:</span>
              <span className="font-mono text-purple-400">{settings.voiceSpeed.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="0.6"
              max="1.6"
              step="0.1"
              value={settings.voiceSpeed}
              onChange={(e) => onUpdateSettings({ voiceSpeed: parseFloat(e.target.value) })}
              className="w-full accent-purple-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-[11px] text-slate-300 mb-1">
              <span>Voice Pitch:</span>
              <span className="font-mono text-blue-400">{settings.voicePitch.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="0.6"
              max="1.4"
              step="0.1"
              value={settings.voicePitch}
              onChange={(e) => onUpdateSettings({ voicePitch: parseFloat(e.target.value) })}
              className="w-full accent-blue-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Android Device Security & Permissions */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 space-y-3 shadow-sm">
        <div className="flex items-center space-x-2">
          <div className="p-2 rounded-xl bg-emerald-500/15 text-emerald-400">
            <Shield className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-200">Android Security & Privacy</h3>
            <p className="text-[10px] text-slate-400">Control sensitive intent prompts</p>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-semibold text-slate-200">Confirm Sensitive Actions</div>
              <div className="text-[10px] text-slate-400">Never execute intents silently without prompt</div>
            </div>
            <input
              type="checkbox"
              checked={settings.confirmSensitiveActions}
              onChange={(e) => onUpdateSettings({ confirmSensitiveActions: e.target.checked })}
              className="w-4 h-4 accent-purple-500 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
            <div>
              <div className="font-semibold text-slate-200">Screen Accessibility Assistance</div>
              <div className="text-[10px] text-slate-400">Allow on-demand screen reading on trigger</div>
            </div>
            <input
              type="checkbox"
              checked={settings.accessibilityServiceEnabled}
              onChange={(e) => onUpdateSettings({ accessibilityServiceEnabled: e.target.checked })}
              className="w-4 h-4 accent-purple-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Android Studio Project Shortcut */}
      <div className="rounded-2xl bg-gradient-to-r from-purple-950/60 to-blue-950/60 border border-purple-500/30 p-4 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <CodeXml className="w-5 h-5 text-cyan-400" />
            <h3 className="text-xs font-bold text-slate-100">Android Studio Project & APK</h3>
          </div>
          <button
            onClick={onNavigateToStudio}
            className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-md"
          >
            Open Workbench
          </button>
        </div>
        <p className="text-[11px] text-slate-300">
          Inspect all Kotlin source files, AndroidManifest.xml, Gradle configurations, and download the full .ZIP.
        </p>
      </div>

      {/* Clear Chat & App Info */}
      <div className="space-y-3 pt-2">
        <button
          onClick={onClearChatHistory}
          className="w-full py-2.5 px-4 rounded-xl border border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 font-semibold text-xs flex items-center justify-center space-x-1.5 transition-colors cursor-pointer"
        >
          <Trash2 className="w-4 h-4" />
          <span>Clear All Chat History</span>
        </button>

        <div className="text-center text-[11px] text-slate-500 space-y-1">
          <p className="font-medium text-slate-400">LalaAI – All-in-One Super AI v2.5.0</p>
          <p>Native Android Jetpack Compose • Material 3 • Kotlin Coroutines</p>
        </div>
      </div>
    </div>
  );
};
