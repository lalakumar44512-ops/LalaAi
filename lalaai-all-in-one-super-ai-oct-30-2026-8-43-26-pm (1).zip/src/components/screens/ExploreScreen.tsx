import React, { useState } from 'react';
import {
  MessageSquare,
  Mic,
  Image as ImageIcon,
  Video,
  Code2,
  Search,
  Languages,
  PenTool,
  GraduationCap,
  FileText,
  FileCheck,
  Calculator,
  BookOpen,
  Music,
  FileMinus,
  Mail,
  BookMarked,
  Film,
  SpellCheck,
  Brain,
  Sparkles,
  ArrowRight,
  X,
  Play,
  Copy,
  Check,
  Volume2
} from 'lucide-react';
import { AIFeatureItem, AppSettings } from '../../types';
import { runAITool } from '../../services/geminiService';
import { voiceManager } from '../../services/voiceService';

interface ExploreScreenProps {
  onSelectFeatureForChat: (feature: AIFeatureItem, prompt: string) => void;
  settings: AppSettings;
}

export const ALL_20_FEATURES: AIFeatureItem[] = [
  {
    id: 'chat',
    number: 1,
    title: 'AI Chat Assistant',
    subtitle: 'Universal multi-turn conversational AI in Hindi & English',
    category: 'Core Brain',
    icon: 'chat',
    defaultPrompt: 'Namaste! Please explain how artificial neural networks work in simple Hindi and English.',
  },
  {
    id: 'voice',
    number: 2,
    title: 'Voice Assistant',
    subtitle: 'Hands-free speech-to-text & instant spoken responses',
    category: 'Core Brain',
    icon: 'mic',
    defaultPrompt: 'Tell me 3 interesting facts about the universe in Hindi.',
  },
  {
    id: 'image',
    number: 3,
    title: 'AI Image Generation',
    subtitle: 'Master prompt engineering, artistic styles & 4K concepts',
    category: 'Creative',
    icon: 'image',
    defaultPrompt: 'Cinematic hyper-realistic portrait of an Indian cybernetic astronaut in Varanasi in year 2077, volumetric neon lighting, 8k.',
  },
  {
    id: 'video',
    number: 4,
    title: 'AI Video Generation',
    subtitle: 'Google Veo prompt builder, 3-scene camera storyboard & director notes',
    category: 'Creative',
    icon: 'video',
    defaultPrompt: 'Drone sweep over glowing Himalayan peaks at dusk with aurora borealis, anamorphic lens, 60fps cinematic.',
  },
  {
    id: 'code',
    number: 5,
    title: 'AI Coding Assistant',
    subtitle: 'Full-stack Android Kotlin, Jetpack Compose, Python & Web',
    category: 'STEM & Code',
    icon: 'code',
    defaultPrompt: 'Write a clean Kotlin Jetpack Compose Custom Canvas progress arc with smooth animation and state hoisting.',
  },
  {
    id: 'search',
    number: 6,
    title: 'AI Web Search Grounding',
    subtitle: 'Real-time live Google Search grounding with verified web sources',
    category: 'Core Brain',
    icon: 'search',
    defaultPrompt: 'What are the most significant technological announcements made by Google and ISRO this year?',
  },
  {
    id: 'translate',
    number: 7,
    title: 'AI Translator',
    subtitle: 'Nuanced translations between Hindi, English, Spanish & 50+ languages',
    category: 'Productivity',
    icon: 'translate',
    defaultPrompt: 'Translate this corporate vision statement into both formal Hindi and conversational Hinglish with pronunciations.',
  },
  {
    id: 'writing',
    number: 8,
    title: 'AI Writing Assistant',
    subtitle: 'Executive proposals, articles, essays & research papers',
    category: 'Productivity',
    icon: 'writing',
    defaultPrompt: 'Write an executive summary and proposal on adopting AI copilots in modern mobile engineering.',
  },
  {
    id: 'homework',
    number: 9,
    title: 'AI Homework Helper',
    subtitle: 'Step-by-step Socratic breakdown with real-world intuition',
    category: 'Education',
    icon: 'homework',
    defaultPrompt: 'Explain how Newton third law applies to rocket propulsion with a step-by-step example.',
  },
  {
    id: 'pdf',
    number: 10,
    title: 'AI PDF Reader',
    subtitle: 'Extract key takeaways, data points & answers from documents',
    category: 'Productivity',
    icon: 'pdf',
    defaultPrompt: 'Analyze this sample project specification document and extract the functional requirements and risks.',
  },
  {
    id: 'document',
    number: 11,
    title: 'AI Document Analyzer',
    subtitle: 'Resume evaluation, agreement analysis & clause breakdown',
    category: 'Productivity',
    icon: 'document',
    defaultPrompt: 'Analyze this Senior Android Engineer resume profile: highlight strengths, missing technical keywords, and suggest improvements.',
  },
  {
    id: 'math',
    number: 12,
    title: 'AI Math Solver',
    subtitle: 'Calculus, linear algebra, trigonometry & step-by-step derivations',
    category: 'STEM & Code',
    icon: 'math',
    defaultPrompt: 'Solve step-by-step: Evaluate the integral of (x^3 * e^(2x)) dx with formula derivation and explanation.',
  },
  {
    id: 'study',
    number: 13,
    title: 'AI Study Assistant',
    subtitle: 'Interactive revision flashcards and multiple-choice quiz generator',
    category: 'Education',
    icon: 'study',
    defaultPrompt: 'Generate 4 high-yield study flashcards and a 3-question multiple choice quiz on Android Activity Lifecycle.',
  },
  {
    id: 'music',
    number: 14,
    title: 'AI Music Generation',
    subtitle: 'Catchy song lyrics, chord progression, tempo & synthesizer vibes',
    category: 'Creative',
    icon: 'music',
    defaultPrompt: 'Write a catchy Cyberpunk Pop song in Hindi-English hybrid with Verse, Pre-Chorus, Chorus, chords, and BPM.',
  },
  {
    id: 'summarize',
    number: 15,
    title: 'AI Summarizer',
    subtitle: 'Instant TL;DR, executive briefs & bullet-point synthesis',
    category: 'Productivity',
    icon: 'summarize',
    defaultPrompt: 'Summarize the core principles of Material Design 3 and Android MVVM into 3 actionable bullet points.',
  },
  {
    id: 'email',
    number: 16,
    title: 'AI Email Writer',
    subtitle: 'Professional, sales pitch, apology & follow-up email drafts',
    category: 'Productivity',
    icon: 'email',
    defaultPrompt: 'Write 3 subject line options and a polite, persuasive follow-up email to a prospective enterprise client.',
  },
  {
    id: 'story',
    number: 17,
    title: 'AI Story Generator',
    subtitle: 'Interactive choose-your-own-path fictional narratives',
    category: 'Creative',
    icon: 'story',
    defaultPrompt: 'Write a suspenseful sci-fi thriller set in an ancient subterranean library beneath Delhi in 2085, ending with 2 branching choices.',
  },
  {
    id: 'content',
    number: 18,
    title: 'AI Content Creator',
    subtitle: 'Viral YouTube scripts, Instagram reels hooks & LinkedIn posts',
    category: 'Creative',
    icon: 'content',
    defaultPrompt: 'Write 3 viral opening 3-second hooks and a 45-second script for an Instagram Reel about AI Android tools.',
  },
  {
    id: 'grammar',
    number: 19,
    title: 'AI Grammar Checker',
    subtitle: 'Proofreading, tone refinement & diff highlight tracker',
    category: 'Productivity',
    icon: 'grammar',
    defaultPrompt: 'Check grammar, fix typos, and improve the sentence elegance of: "Me and him was going to make sure the app was fully builded without any errors."',
  },
  {
    id: 'knowledge',
    number: 20,
    title: 'AI Knowledge Assistant',
    subtitle: 'Deep encyclopedia, historical timelines & conceptual maps',
    category: 'Education',
    icon: 'knowledge',
    defaultPrompt: 'Provide a comprehensive deep-dive timeline into the history of artificial intelligence from Alan Turing to Transformer models.',
  },
];

export const ExploreScreen: React.FC<ExploreScreenProps> = ({
  onSelectFeatureForChat,
  settings,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeModalFeature, setActiveModalFeature] = useState<AIFeatureItem | null>(null);

  // Modal Interactive Tool Workspace State
  const [modalInput, setModalInput] = useState('');
  const [modalResult, setModalResult] = useState('');
  const [isModalLoading, setIsModalLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [speaking, setSpeaking] = useState(false);

  const categories = ['All', 'Core Brain', 'Creative', 'STEM & Code', 'Productivity', 'Education'];

  const filteredFeatures = ALL_20_FEATURES.filter((feat) => {
    const matchesCat = selectedCategory === 'All' || feat.category === selectedCategory;
    const matchesSearch =
      feat.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      feat.subtitle.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const getFeatureIcon = (iconName: string) => {
    switch (iconName) {
      case 'chat':
        return <MessageSquare className="w-5 h-5 text-purple-400" />;
      case 'mic':
        return <Mic className="w-5 h-5 text-rose-400" />;
      case 'image':
        return <ImageIcon className="w-5 h-5 text-emerald-400" />;
      case 'video':
        return <Video className="w-5 h-5 text-red-400" />;
      case 'code':
        return <Code2 className="w-5 h-5 text-blue-400" />;
      case 'search':
        return <Search className="w-5 h-5 text-cyan-400" />;
      case 'translate':
        return <Languages className="w-5 h-5 text-amber-400" />;
      case 'writing':
        return <PenTool className="w-5 h-5 text-indigo-400" />;
      case 'homework':
        return <GraduationCap className="w-5 h-5 text-yellow-400" />;
      case 'pdf':
        return <FileText className="w-5 h-5 text-orange-400" />;
      case 'document':
        return <FileCheck className="w-5 h-5 text-teal-400" />;
      case 'math':
        return <Calculator className="w-5 h-5 text-pink-400" />;
      case 'study':
        return <BookOpen className="w-5 h-5 text-sky-400" />;
      case 'music':
        return <Music className="w-5 h-5 text-violet-400" />;
      case 'summarize':
        return <FileMinus className="w-5 h-5 text-lime-400" />;
      case 'email':
        return <Mail className="w-5 h-5 text-blue-300" />;
      case 'story':
        return <BookMarked className="w-5 h-5 text-fuchsia-400" />;
      case 'content':
        return <Film className="w-5 h-5 text-rose-300" />;
      case 'grammar':
        return <SpellCheck className="w-5 h-5 text-emerald-300" />;
      case 'knowledge':
        return <Brain className="w-5 h-5 text-purple-300" />;
      default:
        return <Sparkles className="w-5 h-5 text-purple-400" />;
    }
  };

  const openToolWorkspace = (feature: AIFeatureItem) => {
    setActiveModalFeature(feature);
    setModalInput(feature.defaultPrompt);
    setModalResult('');
  };

  const executeModalTool = async () => {
    if (!activeModalFeature || !modalInput.trim()) return;
    setIsModalLoading(true);
    setModalResult('');

    try {
      const res = await runAITool(activeModalFeature.id, modalInput.trim(), {}, settings);
      setModalResult(res.text);
    } catch (err: any) {
      setModalResult(`Error: ${err.message || 'Failed to execute tool'}`);
    } finally {
      setIsModalLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(modalResult);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSpeakResult = () => {
    if (speaking) {
      voiceManager.stopSpeaking();
      setSpeaking(false);
    } else {
      setSpeaking(true);
      voiceManager.speak(modalResult, settings.voiceSpeed, settings.voicePitch, () => {
        setSpeaking(false);
      });
    }
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 pb-20 custom-scrollbar">
      {/* Header */}
      <div>
        <div className="flex items-center space-x-2">
          <h2 className="text-lg font-bold text-slate-100">AI Superpowers</h2>
          <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-xs font-mono font-bold border border-purple-500/30">
            20 Tools
          </span>
        </div>
        <p className="text-xs text-slate-400 mt-0.5">
          Dedicated AI modules powered by Gemini 3.8 Flash with Hindi & English intelligence.
        </p>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search features (e.g. math, code, translate, video)..."
          className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-200 placeholder-slate-500 outline-none focus:border-purple-500/50"
        />
      </div>

      {/* Categories Filter */}
      <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === cat
                ? 'bg-purple-600 text-white shadow-sm shadow-purple-600/30'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {filteredFeatures.map((feat) => (
          <div
            key={feat.id}
            onClick={() => openToolWorkspace(feat)}
            className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-purple-500/40 hover:bg-slate-850 transition-all cursor-pointer group shadow-sm flex items-start space-x-3"
          >
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 shrink-0 group-hover:scale-105 transition-transform">
              {getFeatureIcon(feat.icon)}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold text-purple-400">
                  #{feat.number}
                </span>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                  {feat.category}
                </span>
              </div>

              <h4 className="text-xs font-bold text-slate-100 group-hover:text-purple-300 transition-colors mt-0.5 truncate">
                {feat.title}
              </h4>
              <p className="text-[11px] text-slate-400 line-clamp-2 mt-0.5 leading-snug">
                {feat.subtitle}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Dedicated Interactive Tool Modal Workspace */}
      {activeModalFeature && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-lg bg-slate-900 border border-purple-500/30 rounded-3xl p-5 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 shrink-0">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-xl bg-purple-500/20">
                  {getFeatureIcon(activeModalFeature.icon)}
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="text-sm font-bold text-slate-100">{activeModalFeature.title}</h3>
                    <span className="text-[10px] text-purple-400 font-mono">#{activeModalFeature.number}</span>
                  </div>
                  <p className="text-[11px] text-slate-400">{activeModalFeature.subtitle}</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setActiveModalFeature(null);
                  voiceManager.stopSpeaking();
                }}
                className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto py-3 space-y-3 custom-scrollbar">
              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                  Input Prompt / Parameters:
                </label>
                <textarea
                  value={modalInput}
                  onChange={(e) => setModalInput(e.target.value)}
                  rows={3}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-100 placeholder-slate-500 outline-none focus:border-purple-500/50 resize-none font-sans"
                  placeholder="Enter details for this AI tool..."
                />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-[10px] text-slate-400">
                  Powered by {settings.selectedModel} • {settings.language.toUpperCase()}
                </span>
                <button
                  onClick={executeModalTool}
                  disabled={isModalLoading || !modalInput.trim()}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 disabled:opacity-40 text-white text-xs font-semibold shadow-md shadow-purple-600/30 flex items-center space-x-1.5 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{isModalLoading ? 'Generating...' : 'Execute Tool'}</span>
                </button>
              </div>

              {/* Result Area */}
              {modalResult && (
                <div className="p-4 rounded-2xl bg-slate-950 border border-purple-500/30 space-y-2">
                  <div className="flex items-center justify-between pb-1 border-b border-slate-800/80">
                    <span className="text-xs font-bold text-purple-300">Generated Output:</span>
                    <div className="flex items-center space-x-1.5">
                      <button
                        onClick={handleSpeakResult}
                        className="p-1 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-900 transition-colors"
                        title="Read Aloud"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={handleCopy}
                        className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-900 transition-colors"
                        title="Copy text"
                      >
                        {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                  <div className="text-xs text-slate-200 whitespace-pre-wrap leading-relaxed max-h-60 overflow-y-auto custom-scrollbar font-mono">
                    {modalResult}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer: Transfer to full chat */}
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between shrink-0">
              <span className="text-[10px] text-slate-500">Need a multi-turn conversation?</span>
              <button
                onClick={() => {
                  onSelectFeatureForChat(activeModalFeature, modalInput);
                  setActiveModalFeature(null);
                }}
                className="text-xs font-semibold text-purple-400 hover:text-purple-300 flex items-center space-x-1"
              >
                <span>Open in Main AI Chat</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
