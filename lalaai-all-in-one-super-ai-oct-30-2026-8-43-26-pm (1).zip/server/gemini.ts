import { GoogleGenAI } from '@google/genai';

// Initialize Gemini client with process.env.GEMINI_API_KEY and User-Agent telemetry
export function getGeminiClient(customApiKey?: string) {
  const apiKey = customApiKey?.trim() || process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured. Please ensure your Gemini API key is set.');
  }

  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
  image?: {
    data: string; // base64 without prefix or with prefix
    mimeType: string;
  };
}

export interface GenerateOptions {
  model?: string;
  systemInstruction?: string;
  language?: 'auto' | 'en' | 'hi' | 'hinglish';
  personality?: 'helpful' | 'expert' | 'friendly' | 'concise' | 'coder';
  useSearchGrounding?: boolean;
  customApiKey?: string;
}

export const LALAAI_SYSTEM_PROMPT = `You are LalaAI – All-in-One Super AI, an ultra-smart, production-ready Android personal assistant and powerhouse AI.
You excel in both Hindi and English (and natural Hinglish when appropriate).

Key Traits:
1. Highly capable, helpful, polite, and technically adept.
2. When answering in Hindi, use natural, modern Devanagari or Hinglish based on user preference.
3. For coding tasks, provide complete, clean, syntax-highlighted code with concise explanations.
4. For math and science, provide step-by-step logic and clear formulas.
5. Android Phone Control Awareness:
   - When a user asks you to perform an Android action (e.g. open YouTube, call someone, open camera, set alarm, open WhatsApp, launch settings, search Google, navigate), you should answer helpfully AND emit an action tag at the beginning or end of your answer in this format:
     [ACTION:{"type":"OPEN_APP"|"SEARCH_YOUTUBE"|"DIAL_PHONE"|"SEND_WHATSAPP"|"OPEN_CAMERA"|"SET_ALARM"|"OPEN_SETTINGS"|"NAVIGATE"|"WEB_SEARCH","params":{"query":"...","target":"..."}}]
   - Note: Never perform destructive actions without confirmation.
6. Support all 20 AI tools seamlessly.`;

export async function generateGeminiChat(
  messages: ChatMessage[],
  options: GenerateOptions = {}
) {
  const model = options.model || 'gemini-3.8-flash';
  const ai = getGeminiClient(options.customApiKey);

  const langInstruction =
    options.language === 'hi'
      ? 'Always answer in fluent, clear Hindi (Devanagari script).'
      : options.language === 'hinglish'
      ? 'Answer in friendly, natural Hinglish (Hindi written in Roman/English alphabet, popular in India).'
      : options.language === 'en'
      ? 'Answer in crisp, professional English.'
      : 'Automatically detect the user language. If user speaks Hindi or Hinglish, reply in Hindi/Hinglish. Otherwise reply in English.';

  const personalityPrompt =
    options.personality === 'coder'
      ? 'Focus heavily on code architecture, best practices, clean code, and bug-free snippets.'
      : options.personality === 'concise'
      ? 'Keep answers brief, punchy, and direct to the point without filler.'
      : options.personality === 'expert'
      ? 'Provide deep, analytical, research-grade insights and clear step-by-step breakdowns.'
      : 'Be friendly, enthusiastic, futuristic, and helpful.';

  const fullSystemInstruction = `${LALAAI_SYSTEM_PROMPT}\n${langInstruction}\n${personalityPrompt}\n${options.systemInstruction || ''}`;

  // Prepare contents
  const contents = messages.map((m) => {
    if (m.image && m.image.data) {
      // Strip base64 prefix if present
      let rawBase64 = m.image.data;
      if (rawBase64.includes('base64,')) {
        rawBase64 = rawBase64.split('base64,')[1];
      }
      return {
        role: m.role,
        parts: [
          {
            inlineData: {
              data: rawBase64,
              mimeType: m.image.mimeType || 'image/jpeg',
            },
          },
          { text: m.content || 'Analyze this image.' },
        ],
      };
    }
    return {
      role: m.role,
      parts: [{ text: m.content }],
    };
  });

  const config: Record<string, unknown> = {
    systemInstruction: fullSystemInstruction,
  };

  if (options.useSearchGrounding) {
    config.tools = [{ googleSearch: {} }];
  }

  const response = await ai.models.generateContent({
    model,
    contents,
    config,
  });

  const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
  const webSearchQueries = response.candidates?.[0]?.groundingMetadata?.webSearchQueries;

  return {
    text: response.text || '',
    grounding: {
      chunks: groundingChunks,
      queries: webSearchQueries,
    },
  };
}

export async function generateGeminiToolResult(
  feature: string,
  input: string,
  extraParams: Record<string, unknown> = {},
  options: GenerateOptions = {}
) {
  const model = options.model || 'gemini-3.8-flash';
  const ai = getGeminiClient(options.customApiKey);

  let systemInstruction = LALAAI_SYSTEM_PROMPT;
  let useSearch = false;

  switch (feature) {
    case 'code':
      systemInstruction += '\nYou are an elite Android, Kotlin, Python, and Full-Stack Senior Software Architect. Provide production-ready, clean code with explanations and edge-case handling.';
      break;
    case 'search':
      systemInstruction += '\nYou are an AI Web Researcher. Ground your response with up-to-date real-time Google search results, include sources and summaries.';
      useSearch = true;
      break;
    case 'translate':
      systemInstruction += `\nYou are an expert linguist and translator. The target language is: ${extraParams.targetLang || 'Hindi'}. Provide accurate translation, pronunciation/transliteration, and cultural nuance context.`;
      break;
    case 'math':
      systemInstruction += '\nYou are a PhD level Mathematics Professor. Solve problems with step-by-step logic, state formulas clearly, explain each derivation, and give the final answer highlighted.';
      break;
    case 'grammar':
      systemInstruction += '\nYou are an expert editor and grammar checker. Output a clear section with Corrected Version, Original vs Corrected Diff, and explanations of improvements (clarity, tone, punctuation).';
      break;
    case 'summarize':
      systemInstruction += '\nYou are an executive summarizer. Provide: 1. One-sentence TL;DR 2. Key Bullet Points 3. Action Items or Conclusions.';
      break;
    case 'email':
      systemInstruction += `\nYou are an executive communications specialist. Tone: ${extraParams.tone || 'Professional'}. Purpose: ${extraParams.purpose || 'General'}. Provide 3 subject line options followed by the polished email body.`;
      break;
    case 'story':
      systemInstruction += `\nYou are a master creative storyteller. Genre: ${extraParams.genre || 'Sci-Fi'}. Write an engaging, vivid story with rich character depth and atmosphere. Provide 2-3 interactive choices at the end.`;
      break;
    case 'content':
      systemInstruction += `\nYou are a viral social media strategist. Platform: ${extraParams.platform || 'YouTube'}. Provide viral hooks, detailed script/caption, hashtags, and visual direction.`;
      break;
    case 'homework':
      systemInstruction += '\nYou are a patient, encouraging tutor. Break down complex homework questions into intuitive steps, explain foundational principles, and give guided practice.';
      break;
    case 'study':
      systemInstruction += '\nYou are a cognitive study coach. Provide 4-6 interactive Flashcards (Front/Back) and a 3-question Multiple Choice Quiz based on the provided topic.';
      break;
    case 'music':
      systemInstruction += `\nYou are a hit music producer and songwriter. Genre/Vibe: ${extraParams.genre || 'Cyberpunk Pop'}. Provide catchy lyrics (Verse, Chorus, Bridge), recommended BPM, chord progression, and instrumentation notes.`;
      break;
    case 'video':
      systemInstruction += `\nYou are a cinematic video director and Google Veo / AI Video prompt specialist. Provide a structured Video Generation Package with Scene Prompt, Camera Motion, Lighting, Audio Ambience, and 3-scene Storyboard breakdown.`;
      break;
    case 'image':
      systemInstruction += `\nYou are a world-class prompt engineer and AI art director. Provide an optimized master prompt for image generation, negative prompt, aspect ratio advice, and photographic/artistic parameters.`;
      break;
    case 'pdf':
    case 'document':
      systemInstruction += '\nYou are an enterprise document analyst. Extract key findings, critical data points, risks/obligations, and provide a structured breakdown.';
      break;
    case 'knowledge':
      systemInstruction += '\nYou are an omniscient knowledge assistant. Provide an encyclopedia-grade deep dive with historical context, timeline, key facts, and FAQs.';
      break;
    default:
      break;
  }

  const config: Record<string, unknown> = {
    systemInstruction,
  };

  if (useSearch) {
    config.tools = [{ googleSearch: {} }];
  }

  const response = await ai.models.generateContent({
    model,
    contents: input,
    config,
  });

  return {
    text: response.text || '',
    grounding: response.candidates?.[0]?.groundingMetadata,
  };
}
