import { Router, Request, Response } from 'express';
import { generateGeminiChat, generateGeminiToolResult } from './gemini.ts';

export const apiRouter = Router();

// Health check and status
apiRouter.get('/status', (req: Request, res: Response) => {
  const hasEnvKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');
  res.json({
    status: 'online',
    app: 'LalaAI – All-in-One Super AI',
    version: '2.5.0',
    hasApiKey: hasEnvKey,
    supportedModels: ['gemini-3.8-flash', 'gemini-3.1-flash-lite', 'gemini-4-argon'],
    languages: ['Hindi (हिन्दी)', 'English', 'Hinglish'],
  });
});

// Chat endpoint
apiRouter.post('/gemini/chat', async (req: Request, res: Response) => {
  try {
    const { messages, options } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Missing or invalid messages array' });
    }

    const result = await generateGeminiChat(messages, options || {});
    return res.json(result);
  } catch (error: any) {
    console.error('Chat generation error:', error);
    const message = error?.message || 'Failed to generate response';
    return res.status(500).json({ error: message });
  }
});

// Tool / Specific feature endpoint
apiRouter.post('/gemini/tool', async (req: Request, res: Response) => {
  try {
    const { feature, input, extraParams, options } = req.body;
    if (!feature || !input) {
      return res.status(400).json({ error: 'Missing feature or input parameters' });
    }

    const result = await generateGeminiToolResult(feature, input, extraParams || {}, options || {});
    return res.json(result);
  } catch (error: any) {
    console.error('Tool generation error:', error);
    const message = error?.message || 'Failed to generate tool response';
    return res.status(500).json({ error: message });
  }
});

// Device Intent validation & execution audit log simulation
apiRouter.post('/device/intent', (req: Request, res: Response) => {
  const { actionType, params, userConfirmed } = req.body;

  if (!userConfirmed) {
    return res.status(403).json({
      success: false,
      error: 'Security confirmation required before executing device intent.',
    });
  }

  // Construct intent URI for Android
  let intentUri = '';
  switch (actionType) {
    case 'OPEN_APP': {
      const pkg = params?.target || params?.package || 'com.google.android.youtube';
      intentUri = `android-app://${pkg}`;
      break;
    }
    case 'SEARCH_YOUTUBE': {
      const query = encodeURIComponent(params?.query || '');
      intentUri = `vnd.youtube://results?search_query=${query}`;
      break;
    }
    case 'DIAL_PHONE': {
      const number = params?.number || params?.target || '';
      intentUri = `tel:${number}`;
      break;
    }
    case 'SEND_WHATSAPP': {
      const text = encodeURIComponent(params?.text || '');
      intentUri = `https://api.whatsapp.com/send?text=${text}`;
      break;
    }
    case 'OPEN_CAMERA': {
      intentUri = 'intent:#Intent;action=android.media.action.IMAGE_CAPTURE;end';
      break;
    }
    case 'OPEN_SETTINGS': {
      intentUri = 'intent:#Intent;action=android.settings.SETTINGS;end';
      break;
    }
    case 'NAVIGATE': {
      const query = encodeURIComponent(params?.location || params?.query || '');
      intentUri = `geo:0,0?q=${query}`;
      break;
    }
    case 'WEB_SEARCH': {
      const query = encodeURIComponent(params?.query || '');
      intentUri = `https://www.google.com/search?q=${query}`;
      break;
    }
    default:
      intentUri = `intent:#Intent;action=android.intent.action.VIEW;end`;
  }

  return res.json({
    success: true,
    actionType,
    intentUri,
    timestamp: new Date().toISOString(),
    status: 'dispatched',
    message: `Dispatched Android Intent: ${actionType}`,
  });
});
